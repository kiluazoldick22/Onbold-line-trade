import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { TickerHeader } from './components/TickerHeader';
import { ResearchTab } from './components/ResearchTab';
import { ScreenerTab } from './components/ScreenerTab';
import { LiveMonitorTab } from './components/LiveMonitorTab';
import { NewsSentimentTab } from './components/NewsSentimentTab';
import { WhaleTab } from './components/WhaleTab';
import { AutoScanHistoryTab } from './components/AutoScanHistoryTab';
import { SignalNotificationCenter } from './components/SignalNotificationCenter';
import { BottomNav } from './components/BottomNav';
import { SplashScreen } from './components/SplashScreen';
import {
  TickerData,
  OrderBookData,
  TechnicalIndicators,
  FuturesDerivativesData,
  SentimentData,
  NewsItem,
  EconomicEvent,
  WhaleTransaction,
  AnalysisOutput,
  AutoScanConfig,
  CryptoOpportunityItem
} from './types';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState('screener');
  const [currentSymbol, setCurrentSymbol] = useState('BTC/USDT');

  // Notification Drawer State
  const [showHistoryDrawer, setShowHistoryDrawer] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Market Data States
  const [tickerData, setTickerData] = useState<TickerData | null>(null);
  const [orderbookData, setOrderbookData] = useState<OrderBookData | null>(null);
  const [technicals, setTechnicals] = useState<TechnicalIndicators | null>(null);
  const [futuresData, setFuturesData] = useState<FuturesDerivativesData | null>(null);
  const [sentiment, setSentiment] = useState<SentimentData | null>(null);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [events, setEvents] = useState<EconomicEvent[]>([]);
  const [whales, setWhales] = useState<WhaleTransaction[]>([]);
  const [screenerOpportunities, setScreenerOpportunities] = useState<CryptoOpportunityItem[]>([]);

  // AI Analysis & Auto Scan States
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisOutput | null>(null);
  const [loadingTicker, setLoadingTicker] = useState(false);
  const [loadingResearch, setLoadingResearch] = useState(false);
  const [researchProgress, setResearchProgress] = useState('');

  const [autoScanConfig, setAutoScanConfig] = useState<AutoScanConfig>({
    enabled: false,
    intervalSeconds: 30,
    symbols: ['BTC/USDT', 'ETH/USDT', 'SOL/USDT'],
    totalScansCompleted: 0
  });

  // Fetch Live Ticker
  const fetchTicker = useCallback(async (sym: string) => {
    setLoadingTicker(true);
    try {
      const res = await fetch(`/api/market/ticker/${encodeURIComponent(sym)}`);
      if (res.ok) {
        const data = await res.json();
        setTickerData(data);
      }
    } catch (err) {
      console.error('Error fetching ticker:', err);
    } finally {
      setLoadingTicker(false);
    }
  }, []);

  // Fetch Auxiliary Data
  const fetchAuxiliaryData = useCallback(async (sym: string) => {
    try {
      const [depthRes, techRes, futRes, sentRes, newsRes, whaleRes] = await Promise.all([
        fetch(`/api/market/depth/${encodeURIComponent(sym)}`),
        fetch(`/api/market/technicals/${encodeURIComponent(sym)}`),
        fetch(`/api/market/futures/${encodeURIComponent(sym)}`),
        fetch('/api/market/sentiment'),
        fetch('/api/market/news'),
        fetch(`/api/market/whales/${encodeURIComponent(sym)}`)
      ]);

      if (depthRes.ok) setOrderbookData(await depthRes.json());
      if (techRes.ok) setTechnicals(await techRes.json());
      if (futRes.ok) setFuturesData(await futRes.json());
      if (sentRes.ok) setSentiment(await sentRes.json());
      if (newsRes.ok) {
        const nData = await newsRes.json();
        setNews(nData.news || []);
        setEvents(nData.events || []);
      }
      if (whaleRes.ok) setWhales(await whaleRes.json());
    } catch (err) {
      console.error('Error fetching auxiliary data:', err);
    }
  }, []);

  // Trigger Deep AI Research Analysis
  const triggerAiResearch = async (targetSym?: string | unknown) => {
    const symToUse = typeof targetSym === 'string' && targetSym.trim() !== '' ? targetSym : currentSymbol;
    setLoadingResearch(true);
    setResearchProgress(`Mengumpulkan data ticker real-time untuk ${symToUse}...`);

    try {
      setTimeout(() => {
        setResearchProgress('Memverifikasi silang keakuratan harga & menghitung spread antar-bursa...');
      }, 600);

      setTimeout(() => {
        setResearchProgress('Menganalisis kedalaman orderbook, RSI, MACD, & rasio funding rate...');
      }, 1200);

      setTimeout(() => {
        setResearchProgress('Memproses sintesis AI Gemini 3.6 Flash & penyusunan bukti data...');
      }, 1800);

      const res = await fetch('/api/research/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol: symToUse })
      });

      if (res.ok) {
        const result = await res.json();
        setCurrentAnalysis(result);
        if (result.snapshot) {
          setTickerData(result.snapshot.ticker);
          setTechnicals(result.snapshot.technical);
          setOrderbookData(result.snapshot.orderbook);
          setFuturesData(result.snapshot.derivatives);
          setSentiment(result.snapshot.sentiment);
        }
      }
    } catch (err) {
      console.error('Error triggering AI research:', err);
    } finally {
      setLoadingResearch(false);
      setResearchProgress('');
    }
  };

  // Fetch Auto Scan Status
  const fetchAutoScanStatus = async () => {
    try {
      const res = await fetch('/api/agent/auto-scan/status');
      if (res.ok) {
        const cfg = await res.json();
        setAutoScanConfig(cfg);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateAutoScan = async (updated: Partial<AutoScanConfig>) => {
    try {
      const res = await fetch('/api/agent/auto-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...autoScanConfig, ...updated })
      });
      if (res.ok) {
        const cfg = await res.json();
        setAutoScanConfig(cfg);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Load initial symbol data
  useEffect(() => {
    fetchTicker(currentSymbol);
    fetchAuxiliaryData(currentSymbol);
    fetchAutoScanStatus();

    // Background initial screener load
    fetch('/api/market/screener')
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data && Array.isArray(data.opportunities)) {
          setScreenerOpportunities(data.opportunities);
        }
      })
      .catch(() => {});
  }, [currentSymbol, fetchTicker, fetchAuxiliaryData]);

  // Periodic ticker & screener refresh every 15 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      fetchTicker(currentSymbol);

      fetch('/api/market/screener')
        .then(res => res.ok ? res.json() : null)
        .then(data => {
          if (data && Array.isArray(data.opportunities)) {
            setScreenerOpportunities(data.opportunities);
          }
        })
        .catch(() => {});
    }, 15000);
    return () => clearInterval(timer);
  }, [currentSymbol, fetchTicker]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Animated Splash Screen on Initial App Load */}
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}

      {/* Real-time Market Signal Notification System (Audio Chime, Push, Toast Banners) */}
      <SignalNotificationCenter
        screenerOpportunities={screenerOpportunities}
        onSelectSymbolForResearch={(sym) => {
          setCurrentSymbol(sym);
          setActiveTab('research');
          triggerAiResearch(sym);
        }}
        showHistoryDrawer={showHistoryDrawer}
        setShowHistoryDrawer={setShowHistoryDrawer}
        unreadCount={unreadCount}
        setUnreadCount={setUnreadCount}
      />

      {/* App Header & Desktop Navigation */}
      <Header
        autoScanConfig={autoScanConfig}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        geminiConnected={true}
        onUpdateAutoScan={handleUpdateAutoScan}
      />

      {/* Ticker & Multi-Exchange Live Banner */}
      <TickerHeader
        currentSymbol={currentSymbol}
        setCurrentSymbol={setCurrentSymbol}
        tickerData={tickerData}
        loadingTicker={loadingTicker}
        onRefreshTicker={() => {
          fetchTicker(currentSymbol);
          fetchAuxiliaryData(currentSymbol);
        }}
      />

      {/* Main Content Area (Extra padding bottom for mobile bottom nav) */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 pb-24 md:pb-8">
        {activeTab === 'screener' && (
          <ScreenerTab
            onSelectCoinForResearch={(sym) => {
              setCurrentSymbol(sym);
              setActiveTab('research');
              triggerAiResearch(sym);
            }}
            onOpportunitiesUpdate={(opps) => setScreenerOpportunities(opps)}
          />
        )}

        {activeTab === 'research' && (
          <ResearchTab
            currentSymbol={currentSymbol}
            analysis={currentAnalysis}
            loading={loadingResearch}
            progressStep={researchProgress}
            onTriggerResearch={triggerAiResearch}
          />
        )}

        {activeTab === 'monitor' && (
          <LiveMonitorTab
            currentSymbol={currentSymbol}
            tickerData={tickerData}
            orderbookData={orderbookData}
            technicals={technicals}
            futuresData={futuresData}
            loading={loadingTicker}
            onRefresh={() => {
              fetchTicker(currentSymbol);
              fetchAuxiliaryData(currentSymbol);
            }}
          />
        )}

        {activeTab === 'news' && (
          <NewsSentimentTab
            news={news}
            events={events}
            sentiment={sentiment}
            loading={loadingTicker}
          />
        )}

        {activeTab === 'whales' && (
          <WhaleTab
            currentSymbol={currentSymbol}
            whales={whales}
            futuresData={futuresData}
          />
        )}

        {activeTab === 'history' && (
          <AutoScanHistoryTab
            autoScanConfig={autoScanConfig}
            onUpdateAutoScan={handleUpdateAutoScan}
            onSelectReport={report => {
              setCurrentAnalysis(report);
              setCurrentSymbol(report.symbol);
              setActiveTab('research');
            }}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        unreadCount={unreadCount}
        onOpenNotifications={() => {
          setShowHistoryDrawer(true);
          setUnreadCount(0);
        }}
        onOpenSettings={() => {}}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 mb-16 md:mb-0 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 space-y-1.5">
          <p className="font-semibold text-slate-300">
            Dibuat & Dikembangkan oleh <span className="text-cyan-400 font-bold underline decoration-cyan-500/40">Ahmad Sobirin</span>
          </p>
          <p>AI Trading Research Agent v2.5 — Real-Time Automated Market Research System</p>
          <p className="text-[11px] text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Sistem ini berfungsi untuk riset, pemindaian sinyal, dan analisis teknikal berbasis bukti kuantitatif.
          </p>
        </div>
      </footer>

    </div>
  );
}
