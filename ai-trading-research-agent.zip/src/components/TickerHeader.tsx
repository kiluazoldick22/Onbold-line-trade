import React, { useState } from 'react';
import { Search, CheckCircle2, AlertTriangle, RefreshCcw, ExternalLink, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { TickerData } from '../types';

interface TickerHeaderProps {
  currentSymbol: string;
  setCurrentSymbol: (sym: string) => void;
  tickerData: TickerData | null;
  loadingTicker: boolean;
  onRefreshTicker: () => void;
}

const POPULAR_PAIRS = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'XRP/USDT', 'DOGE/USDT', 'BNB/USDT'];

export const TickerHeader: React.FC<TickerHeaderProps> = ({
  currentSymbol,
  setCurrentSymbol,
  tickerData,
  loadingTicker,
  onRefreshTicker
}) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    let formatted = searchInput.trim().toUpperCase();
    if (!formatted.includes('/')) {
      formatted = `${formatted}/USDT`;
    }
    setCurrentSymbol(formatted);
    setSearchInput('');
  };

  return (
    <div className="bg-slate-900/90 border-b border-slate-800 py-3.5 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-3">
        
        {/* Symbol Bar & Search */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* Quick Selectors */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            <span className="text-xs font-semibold text-slate-400 mr-1 flex items-center gap-1">
              Simbol:
            </span>
            {POPULAR_PAIRS.map(pair => (
              <button
                key={pair}
                onClick={() => setCurrentSymbol(pair)}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  currentSymbol === pair
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 ring-1 ring-blue-400'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                }`}
              >
                {pair}
              </button>
            ))}
          </div>

          {/* Search Form */}
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
            <div className="relative flex-1 md:w-52">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari simbol (e.g. ADA, AVAX)"
                value={searchInput}
                onChange={e => setSearchInput(e.target.value)}
                className="w-full bg-slate-800/90 border border-slate-700 text-slate-100 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 placeholder-slate-500"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium rounded-lg transition-colors"
            >
              Cari
            </button>
            <button
              type="button"
              onClick={onRefreshTicker}
              disabled={loadingTicker}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg transition-colors"
              title="Perbarui Data Ticker"
            >
              <RefreshCcw className={`w-4 h-4 ${loadingTicker ? 'animate-spin text-blue-400' : ''}`} />
            </button>
          </form>
        </div>

        {/* Live Multi-Exchange Price Banner */}
        {tickerData && (
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
            
            {/* Primary Price Metric */}
            <div className="md:col-span-4 flex items-center gap-4 border-b md:border-b-0 md:border-r border-slate-800 pb-2 md:pb-0 pr-0 md:pr-4">
              <div>
                <div className="text-xs text-slate-400 font-medium">Harga Utama ({tickerData.primarySource})</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-slate-100 tracking-tight">
                    ${tickerData.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
                  </span>
                  <span className={`text-xs font-bold flex items-center ${
                    tickerData.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {tickerData.change24h >= 0 ? <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" /> : <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />}
                    {tickerData.change24h >= 0 ? '+' : ''}{tickerData.change24h}%
                  </span>
                </div>
              </div>

              <div className="hidden sm:block text-xs border-l border-slate-800 pl-3 space-y-0.5 text-slate-400">
                <div>High 24h: <span className="text-slate-200 font-mono">${tickerData.high24h}</span></div>
                <div>Low 24h: <span className="text-slate-200 font-mono">${tickerData.low24h}</span></div>
                <div>Vol 24h: <span className="text-slate-200 font-mono">${(tickerData.volume24h / 1e6).toFixed(1)}M</span></div>
              </div>
            </div>

            {/* Cross-Source Verification Prices */}
            <div className="md:col-span-5 flex flex-wrap items-center gap-3 text-xs">
              <span className="text-slate-400 font-semibold text-[11px] block w-full sm:w-auto">Verifikasi Silang Bursa:</span>
              
              {tickerData.sourcePrices.binance && (
                <div className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-md">
                  <span className="text-slate-400 text-[10px]">Binance: </span>
                  <span className="font-mono text-slate-200 font-bold">${tickerData.sourcePrices.binance}</span>
                </div>
              )}

              {tickerData.sourcePrices.kucoin && (
                <div className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-md">
                  <span className="text-slate-400 text-[10px]">KuCoin: </span>
                  <span className="font-mono text-slate-200 font-bold">${tickerData.sourcePrices.kucoin}</span>
                </div>
              )}

              {tickerData.sourcePrices.coingecko && (
                <div className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-md">
                  <span className="text-slate-400 text-[10px]">CoinGecko: </span>
                  <span className="font-mono text-slate-200 font-bold">${tickerData.sourcePrices.coingecko}</span>
                </div>
              )}

              {tickerData.sourcePrices.cryptocompare && (
                <div className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-md">
                  <span className="text-slate-400 text-[10px]">CryptoCompare: </span>
                  <span className="font-mono text-slate-200 font-bold">${tickerData.sourcePrices.cryptocompare}</span>
                </div>
              )}
            </div>

            {/* Accuracy Verification Shield */}
            <div className="md:col-span-3 flex justify-end">
              <div className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 text-xs font-semibold ${
                tickerData.verificationStatus === 'VERIFIED_HIGH'
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                  : tickerData.verificationStatus === 'VERIFIED_MODERATE'
                  ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                  : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
              }`}>
                {tickerData.verificationStatus === 'VERIFIED_HIGH' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <div>
                  <div className="leading-tight">
                    {tickerData.verificationStatus === 'VERIFIED_HIGH'
                      ? 'Terverifikasi Akurat'
                      : tickerData.verificationStatus === 'VERIFIED_MODERATE'
                      ? 'Spread Moderat'
                      : 'Cek Beda Harga'}
                  </div>
                  <div className="text-[10px] font-normal opacity-80 font-mono">
                    Spread: {tickerData.spreadPercent}%
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
