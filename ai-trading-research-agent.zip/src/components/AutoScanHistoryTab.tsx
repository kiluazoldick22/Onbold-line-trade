import React, { useState, useEffect } from 'react';
import {
  Activity,
  Database,
  Download,
  Trash2,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Filter,
  FileSpreadsheet
} from 'lucide-react';
import { AnalysisOutput, AutoScanConfig, FailoverLog } from '../types';

interface AutoScanHistoryTabProps {
  autoScanConfig: AutoScanConfig;
  onUpdateAutoScan: (config: Partial<AutoScanConfig>) => void;
  onSelectReport: (report: AnalysisOutput) => void;
}

export const AutoScanHistoryTab: React.FC<AutoScanHistoryTabProps> = ({
  autoScanConfig,
  onUpdateAutoScan,
  onSelectReport
}) => {
  const [history, setHistory] = useState<AnalysisOutput[]>([]);
  const [failoverLogs, setFailoverLogs] = useState<FailoverLog[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');

  const fetchHistory = async () => {
    setLoadingHistory(true);
    try {
      const res = await fetch('/api/research/history?limit=100');
      if (res.ok) {
        const data = await res.json();
        setHistory(data);
      }
    } catch (e) {
      console.error('Failed to fetch history', e);
    } finally {
      setLoadingHistory(false);
    }
  };

  const fetchFailovers = async () => {
    try {
      const res = await fetch('/api/failover/logs');
      if (res.ok) {
        const data = await res.json();
        setFailoverLogs(data);
      }
    } catch (e) {
      console.error('Failed to fetch failover logs', e);
    }
  };

  useEffect(() => {
    fetchHistory();
    fetchFailovers();
  }, []);

  const handleDeleteReport = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Hapus laporan riset ini dari database?')) return;
    try {
      const res = await fetch(`/api/research/history/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setHistory(prev => prev.filter(item => item.id !== id));
      }
    } catch (err) {
      console.error('Failed to delete report', err);
    }
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `ai_trading_research_db_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleExportCsv = () => {
    if (history.length === 0) return;
    const headers = ['ID', 'Symbol', 'Action', 'ConfidenceScore', 'Price', 'PotentialEntry', 'StopLoss', 'TakeProfit1', 'Timestamp'];
    const rows = history.map(item => [
      item.id,
      item.symbol,
      item.action,
      `${item.confidenceScore}%`,
      item.currentPrice,
      item.potentialEntry,
      item.suggestedStopLoss,
      item.suggestedTakeProfit1,
      item.timestamp
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ai_trading_research_history_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const filteredHistory = history.filter(item => {
    const matchesSearch = item.symbol.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAction = actionFilter === 'ALL' || item.action.toUpperCase() === actionFilter.toUpperCase();
    return matchesSearch && matchesAction;
  });

  return (
    <div className="space-y-6">
      
      {/* Auto Scan Controls Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" />
              Kontrol Agen Auto-Scan Berkelanjutan
            </h2>
            <p className="text-xs text-slate-400">
              Agen akan memperbarui data dan membuat analisis baru secara otomatis di latar belakang.
            </p>
          </div>

          <button
            onClick={() => onUpdateAutoScan({ enabled: !autoScanConfig.enabled })}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              autoScanConfig.enabled
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 shadow-md shadow-emerald-500/20'
            }`}
          >
            {autoScanConfig.enabled ? 'Hentikan Auto-Scan' : 'Aktifkan Auto-Scan Otomatis'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-medium">Interval Update</span>
            <select
              value={autoScanConfig.intervalSeconds}
              onChange={e => onUpdateAutoScan({ intervalSeconds: parseInt(e.target.value, 10) })}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-emerald-500"
            >
              <option value={15}>Setiap 15 Detik (Ultra Fast)</option>
              <option value={30}>Setiap 30 Detik (Rekomendasi)</option>
              <option value={60}>Setiap 1 Menit</option>
              <option value={300}>Setiap 5 Menit</option>
            </select>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-medium">Status Agen</span>
            <div className="font-bold font-mono text-emerald-400 text-sm flex items-center gap-1.5 pt-1">
              <span className={`w-2 h-2 rounded-full ${autoScanConfig.enabled ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`}></span>
              {autoScanConfig.enabled ? 'Aktif Berjalan' : 'Non-Aktif (Manual Mode)'}
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-medium">Total Scan Selesai</span>
            <div className="font-bold font-mono text-slate-200 text-sm pt-1">
              {autoScanConfig.totalScansCompleted || 0} Siklus Terpancur
            </div>
          </div>

        </div>
      </div>

      {/* Database History Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        
        {/* Header & Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-400" />
              Riwayat Database Analisis Pasar ({filteredHistory.length})
            </h3>
            <p className="text-xs text-slate-400">Tersimpan secara permanen di /data/research_db.json</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Filter simbol..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg pl-8 pr-2.5 py-1.5 focus:outline-none"
              />
            </div>

            {/* Action Filter */}
            <select
              value={actionFilter}
              onChange={e => setActionFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="ALL">Semua Sinyal</option>
              <option value="BUY">BUY Sahaja</option>
              <option value="SELL">SELL Sahaja</option>
              <option value="HOLD">HOLD Sahaja</option>
            </select>

            {/* Export Buttons */}
            <button
              onClick={handleExportJson}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export JSON</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={fetchHistory}
              disabled={loadingHistory}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg"
              title="Refresh DB"
            >
              <RefreshCw className={`w-4 h-4 ${loadingHistory ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* History Table */}
        {filteredHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3">Waktu</th>
                  <th className="p-3">Simbol</th>
                  <th className="p-3">Rekomendasi</th>
                  <th className="p-3">Confidence</th>
                  <th className="p-3">Harga Saat Riset</th>
                  <th className="p-3">Entry Zone</th>
                  <th className="p-3">Stop Loss</th>
                  <th className="p-3">Take Profit 1</th>
                  <th className="p-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredHistory.map(item => (
                  <tr
                    key={item.id}
                    onClick={() => onSelectReport(item)}
                    className="hover:bg-slate-800/50 cursor-pointer transition-colors"
                  >
                    <td className="p-3 font-mono text-[11px] text-slate-400">
                      {new Date(item.timestamp).toLocaleString()}
                    </td>
                    <td className="p-3 font-bold text-slate-100">{item.symbol}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        item.action === 'BUY' ? 'bg-emerald-500/20 text-emerald-400' :
                        item.action === 'SELL' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {item.action}
                      </span>
                    </td>
                    <td className="p-3 font-mono font-bold text-slate-200">{item.confidenceScore}%</td>
                    <td className="p-3 font-mono text-slate-200">${item.currentPrice}</td>
                    <td className="p-3 font-mono text-blue-300">${item.potentialEntry}</td>
                    <td className="p-3 font-mono text-rose-300">${item.suggestedStopLoss}</td>
                    <td className="p-3 font-mono text-emerald-300">${item.suggestedTakeProfit1}</td>
                    <td className="p-3 text-right">
                      <button
                        onClick={e => handleDeleteReport(item.id, e)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                        title="Hapus laporan ini"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center text-xs text-slate-500 py-10">
            {loadingHistory ? 'Memuat database riset...' : 'Belum ada laporan riset tersimpan dalam database.'}
          </div>
        )}

      </div>

      {/* System Failover Audit Logs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Audit Log Redundansi & Failover Otomatis API ({failoverLogs.length})
        </h3>
        <p className="text-xs text-slate-400">
          Mencatat setiap kejadian ketika bursa utama gagal diakses, dan agen beralih secara otomatis ke bursa cadangan.
        </p>

        {failoverLogs.length > 0 ? (
          <div className="space-y-2">
            {failoverLogs.map(log => (
              <div key={log.id} className="bg-slate-950 p-2.5 rounded-xl border border-amber-900/20 text-xs flex items-center justify-between font-mono">
                <span className="text-amber-300 font-bold">[{log.failedSource}] Gagal &rarr; Beralih Ke [{log.usedFallbackSource}]</span>
                <span className="text-slate-500 text-[10px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Semua bursa utama (Binance, KuCoin, CoinGecko) terhubung dengan lancar. Belum ada insiden failover.</span>
          </div>
        )}
      </div>

    </div>
  );
};
