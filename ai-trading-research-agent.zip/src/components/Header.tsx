import React, { useState } from 'react';
import { Bot, ShieldCheck, Database, Cpu, Activity, Settings, Check, Clock, X } from 'lucide-react';
import { AutoScanConfig } from '../types';

interface HeaderProps {
  autoScanConfig: AutoScanConfig;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  geminiConnected: boolean;
  onUpdateAutoScan?: (updated: Partial<AutoScanConfig>) => void;
}

export const Header: React.FC<HeaderProps> = ({
  autoScanConfig,
  activeTab,
  setActiveTab,
  onUpdateAutoScan
}) => {
  const [showSettings, setShowSettings] = useState(false);

  const availableIntervals = [15, 30, 60, 120, 300];

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-2.5 sm:py-3 gap-2">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-2.5">
            <div className="p-2 sm:p-2.5 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl shadow-lg shadow-cyan-500/20 text-white flex-shrink-0">
              <Bot className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <h1 className="text-sm sm:text-lg font-black text-slate-100 tracking-tight">AI Trading Research</h1>
                <span className="px-1.5 py-0.5 text-[9px] sm:text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  LIVE
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 rounded-md shrink-0">
                  By Ahmad Sobirin
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Riset Pasar, Verifikasi Multi-Exchange, & Analisis Kuantitatif • <span className="text-cyan-400 font-medium">Ahmad Sobirin</span></p>
            </div>
          </div>

          {/* System Badges & Settings Trigger */}
          <div className="flex items-center gap-1.5 sm:gap-2 text-xs relative">
            {/* Auto Scan Status & Interactive Settings Button */}
            <div className="relative">
              <button
                onClick={() => setShowSettings(!showSettings)}
                className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-semibold flex items-center gap-1.5 transition-all shadow-sm ${
                  autoScanConfig.enabled
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25'
                    : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
                title="Klik untuk membuka Pengaturan Auto-Scan 30 Seken"
              >
                <Activity className={`w-3.5 h-3.5 ${autoScanConfig.enabled ? 'animate-spin text-emerald-400' : 'text-slate-400'}`} />
                <span>Auto-Scan:</span>
                <span className="font-bold text-amber-300 font-mono">{autoScanConfig.enabled ? `${autoScanConfig.intervalSeconds}s` : 'Off'}</span>
                <Settings className="w-3 h-3 text-slate-400 ml-0.5" />
              </button>

              {/* Popover Settings Dropdown */}
              {showSettings && (
                <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-4 z-50 text-slate-100 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-cyan-400" />
                      <span className="text-xs font-bold text-slate-100">Pengaturan Auto-Scan Real-Time</span>
                    </div>
                    <button
                      onClick={() => setShowSettings(false)}
                      className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="py-3 space-y-3">
                    {/* Toggle Switch */}
                    <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                      <div>
                        <div className="text-xs font-bold text-slate-200">Status Auto-Scan</div>
                        <div className="text-[10px] text-slate-400">Pindai pasar otomatis secara berkala</div>
                      </div>
                      <button
                        onClick={() => {
                          if (onUpdateAutoScan) {
                            onUpdateAutoScan({ enabled: !autoScanConfig.enabled });
                          }
                        }}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                          autoScanConfig.enabled
                            ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {autoScanConfig.enabled ? 'AKTIF' : 'NONAKTIF'}
                      </button>
                    </div>

                    {/* Interval Selector */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
                        <span>INTERVAL WAKTU SCAN:</span>
                        <span className="text-amber-300 font-mono font-bold">{autoScanConfig.intervalSeconds} Detik</span>
                      </label>
                      <div className="grid grid-cols-4 gap-1.5">
                        {availableIntervals.map(sec => (
                          <button
                            key={sec}
                            onClick={() => {
                              if (onUpdateAutoScan) {
                                onUpdateAutoScan({ intervalSeconds: sec });
                              }
                            }}
                            className={`py-1.5 rounded-lg text-xs font-bold font-mono transition-all border ${
                              autoScanConfig.intervalSeconds === sec
                                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-sm'
                                : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                            }`}
                          >
                            {sec}s {sec === 30 ? '🔥' : ''}
                          </button>
                        ))}
                      </div>
                      <p className="text-[10px] text-slate-400 pt-0.5">
                        *Opsi <span className="text-amber-300 font-bold">30 Seken (30s)</span> direkomendasikan untuk pemindaian presisi tinggi.
                      </p>
                    </div>

                    {/* Target Coins */}
                    <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                      <span>Koin Target:</span>
                      <span className="font-mono text-cyan-300 font-semibold">{(autoScanConfig.symbols || ['BTC/USDT', 'ETH/USDT']).join(', ')}</span>
                    </div>

                    {/* Total completed */}
                    <div className="text-[10px] text-slate-400 flex items-center justify-between">
                      <span>Total Pemindaian:</span>
                      <span className="font-mono text-emerald-400 font-bold">{autoScanConfig.totalScansCompleted || 0} scan</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex justify-end">
                    <button
                      onClick={() => {
                        setShowSettings(false);
                        setActiveTab('history');
                      }}
                      className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                    >
                      Lihat Log Database & Auto-Scan →
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Zero Execution Safeguard */}
            <div className="hidden sm:flex px-2.5 py-1 bg-blue-500/10 text-blue-300 border border-blue-500/20 rounded-lg items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
              <span>Proteksi 0 Executions</span>
            </div>

            {/* DB Persistence */}
            <div className="hidden md:flex px-2.5 py-1 bg-slate-800 text-slate-300 border border-slate-700 rounded-lg items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-cyan-400" />
              <span>DB Saved</span>
            </div>

            {/* AI Engine Status */}
            <div className="hidden lg:flex px-2.5 py-1 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-lg items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Gemini 3.6 Flash</span>
            </div>
          </div>

        </div>

        {/* Desktop Header Navigation Bar */}
        <div className="hidden md:flex items-center gap-1 border-t border-slate-800/80 pt-2 pb-1 overflow-x-auto no-scrollbar">
          {[
            { id: 'screener', label: '🔥 Pemindai Pasar (20+ Coin)' },
            { id: 'research', label: '🤖 Riset AI Deep Scan' },
            { id: 'monitor', label: '📊 Pantauan Multi-Exchange' },
            { id: 'news', label: '📰 Berita & Kalender Ekonomi' },
            { id: 'whales', label: '🐋 Whale & Derivatives' },
            { id: 'history', label: '🔄 Auto-Scan & Database Logs' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};

