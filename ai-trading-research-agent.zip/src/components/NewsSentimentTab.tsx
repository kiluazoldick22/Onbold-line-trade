import React from 'react';
import { Newspaper, Calendar, MessageSquare, ExternalLink, TrendingUp, TrendingDown, Clock, ShieldAlert } from 'lucide-react';
import { NewsItem, EconomicEvent, SentimentData } from '../types';

interface NewsSentimentTabProps {
  news: NewsItem[];
  events: EconomicEvent[];
  sentiment: SentimentData | null;
  loading: boolean;
}

export const NewsSentimentTab: React.FC<NewsSentimentTabProps> = ({
  news,
  events,
  sentiment,
  loading
}) => {
  return (
    <div className="space-y-6">
      
      {/* Top Overview Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        
        {/* Fear & Greed Meter */}
        <div className="md:col-span-5 bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Crypto Fear & Greed Index</div>
            <div className="text-2xl font-black text-slate-100 mt-0.5">
              {sentiment?.fearAndGreedIndex || 62} / 100
            </div>
            <span className="text-xs font-semibold text-purple-400">
              Kategori: {sentiment?.fearAndGreedLabel || 'Greed'}
            </span>
          </div>

          <div className="w-16 h-16 rounded-full border-4 border-purple-500/30 flex items-center justify-center font-mono font-bold text-lg text-purple-300">
            {sentiment?.fearAndGreedIndex || 62}
          </div>
        </div>

        {/* Social Sentiment Radar */}
        <div className="md:col-span-7 grid grid-cols-3 gap-3 text-xs">
          
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 font-medium block">X / Twitter</span>
            <span className="font-bold font-mono text-cyan-300 text-sm">
              {sentiment?.socialBreakdown.xTwitter.score || 68} / 100
            </span>
            <span className="text-[10px] text-slate-500 block truncate">
              {sentiment?.socialBreakdown.xTwitter.sentiment || 'Bullish Chatter'}
            </span>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 font-medium block">Reddit Crypto</span>
            <span className="font-bold font-mono text-cyan-300 text-sm">
              {sentiment?.socialBreakdown.reddit.score || 55} / 100
            </span>
            <span className="text-[10px] text-slate-500 block truncate">
              {sentiment?.socialBreakdown.reddit.sentiment || 'Positive DD'}
            </span>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 font-medium block">Telegram / Discord</span>
            <span className="font-bold font-mono text-cyan-300 text-sm">
              {sentiment?.socialBreakdown.telegramDiscord.score || 62} / 100
            </span>
            <span className="text-[10px] text-slate-500 block truncate">
              {sentiment?.socialBreakdown.telegramDiscord.sentiment || 'Accumulation'}
            </span>
          </div>

        </div>

      </div>

      {/* Main Grid: News Feed & Economic Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Real-time Crypto News Feed */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Newspaper className="w-4 h-4 text-cyan-400" />
              Berita Crypto & Pasar Terbaru (Live RSS)
            </h3>
            <span className="text-[10px] text-slate-400">CoinTelegraph, CoinDesk, Decrypt</span>
          </div>

          <div className="space-y-3">
            {news.map(item => (
              <div key={item.id} className="bg-slate-950/70 border border-slate-800/80 p-3.5 rounded-xl space-y-1.5 hover:border-slate-700 transition-colors">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded font-semibold">{item.source}</span>
                  <span className={`px-2 py-0.5 rounded font-bold ${
                    item.sentiment === 'BULLISH' ? 'bg-emerald-500/20 text-emerald-400' :
                    item.sentiment === 'BEARISH' ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {item.sentiment}
                  </span>
                </div>

                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-slate-100 hover:text-cyan-300 transition-colors flex items-start gap-1"
                >
                  <span>{item.title}</span>
                  <ExternalLink className="w-3 h-3 text-slate-500 shrink-0 mt-0.5" />
                </a>

                <p className="text-[11px] text-slate-400 line-clamp-2">{item.summary}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Economic Calendar Events */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              Kalender Ekonomi & Event Makro
            </h3>
            <span className="text-[10px] text-slate-400">Federal Reserve, CPI, NFP</span>
          </div>

          <div className="space-y-3">
            {events.map(evt => (
              <div key={evt.id} className="bg-slate-950/70 border border-amber-900/20 p-3.5 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-amber-300">{evt.eventName}</span>
                  <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 text-[10px] font-bold rounded">
                    Dampak: {evt.importance}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 font-mono">
                  <div>Prakiraan (Forecast): <span className="text-slate-200">{evt.forecast}</span></div>
                  <div>Sebelumnya (Previous): <span className="text-slate-200">{evt.previous}</span></div>
                </div>

                <div className="text-[11px] text-slate-300 bg-slate-900/80 p-2 rounded border border-slate-800">
                  <span className="font-semibold text-amber-400/90 block text-[10px]">Implikasi Pasar:</span>
                  {evt.impactOnCrypto}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
