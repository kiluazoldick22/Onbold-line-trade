import React from 'react';
import { Flame, Bot, Activity, Newspaper, Bell, Sliders } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadCount: number;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  unreadCount,
  onOpenNotifications,
  onOpenSettings
}) => {
  const navItems = [
    { id: 'screener', label: 'Pemindai', icon: Flame },
    { id: 'research', label: 'Riset AI', icon: Bot },
    { id: 'monitor', label: 'Pantauan', icon: Activity },
    { id: 'news', label: 'Berita', icon: Newspaper }
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-slate-900/95 backdrop-blur-xl border-t border-slate-800/80 md:hidden px-2 py-1.5 shadow-2xl">
      <div className="grid grid-cols-5 items-center max-w-md mx-auto text-center">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all ${
                isActive
                  ? 'text-cyan-400 font-bold bg-cyan-500/10'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'scale-110 text-cyan-400' : ''}`} />
              <span className="text-[10px] tracking-tight mt-0.5 truncate max-w-full">
                {item.label}
              </span>
            </button>
          );
        })}

        {/* Notifications & Signal Drawer Button */}
        <button
          onClick={onOpenNotifications}
          className="relative flex flex-col items-center justify-center py-1.5 px-1 rounded-xl text-slate-400 hover:text-slate-200 transition-all"
        >
          <div className="relative">
            <Bell className="w-5 h-5 text-amber-400" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1.5 px-1.5 py-0.2 text-[9px] bg-rose-500 text-white font-black rounded-full animate-pulse shadow-md">
                {unreadCount}
              </span>
            )}
          </div>
          <span className="text-[10px] tracking-tight mt-0.5 text-slate-300 font-medium">
            Sinyal
          </span>
        </button>
      </div>
    </nav>
  );
};
