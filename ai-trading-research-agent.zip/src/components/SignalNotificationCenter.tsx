import React, { useState, useEffect } from 'react';
import {
  Bell,
  Volume2,
  VolumeX,
  Smartphone,
  X,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Sliders,
  Play
} from 'lucide-react';
import { CryptoOpportunityItem } from '../types';
import { playBuySignalSound, playSellSignalSound } from '../utils/audioAlert';

export interface SignalNotificationItem {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  confidence: number;
  reason: string;
  timestamp: string;
  read: boolean;
}

interface SignalNotificationCenterProps {
  screenerOpportunities: CryptoOpportunityItem[];
  onSelectSymbolForResearch: (symbol: string) => void;
  showHistoryDrawer: boolean;
  setShowHistoryDrawer: (show: boolean) => void;
  unreadCount: number;
  setUnreadCount: (count: number) => void;
}

export const SignalNotificationCenter: React.FC<SignalNotificationCenterProps> = ({
  screenerOpportunities,
  onSelectSymbolForResearch,
  showHistoryDrawer,
  setShowHistoryDrawer,
  unreadCount,
  setUnreadCount
}) => {
  // Settings State
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>('default');
  const [minConfidence, setMinConfidence] = useState<number>(65);
  const [filterType, setFilterType] = useState<'ALL' | 'BUY_ONLY' | 'SELL_ONLY'>('ALL');

  // Active Signals & History
  const [notifications, setNotifications] = useState<SignalNotificationItem[]>([]);
  const [activeToast, setActiveToast] = useState<SignalNotificationItem | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [notifiedIds, setNotifiedIds] = useState<Set<string>>(new Set());

  // Check Browser Notification Permission
  useEffect(() => {
    if ('Notification' in window) {
      setPushPermission(Notification.permission);
    }
  }, []);

  const requestPushPermission = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      setPushPermission(perm);
      if (perm === 'granted') {
        new Notification('🤖 Notifikasi AI Signal Aktif!', {
          body: 'Sistem siap mengirim notifikasi real-time saat ada sinyal BUY/SELL berpotensi tinggi.',
          icon: '/favicon.ico'
        });
      }
    }
  };

  // Sync unread count to parent component safely
  useEffect(() => {
    const count = notifications.filter((n) => !n.read).length;
    setUnreadCount(count);
  }, [notifications, setUnreadCount]);

  // Evaluate incoming signals from Screener
  useEffect(() => {
    if (!notificationsEnabled || !screenerOpportunities || screenerOpportunities.length === 0) return;

    screenerOpportunities.forEach((opp) => {
      const isBuy = opp.signal === 'STRONG_BUY' || opp.signal === 'BUY';
      const isSell = opp.signal === 'STRONG_SELL' || opp.signal === 'SELL';

      if (!isBuy && !isSell) return;

      // Filter check
      if (filterType === 'BUY_ONLY' && !isBuy) return;
      if (filterType === 'SELL_ONLY' && !isSell) return;
      if (opp.confidence < minConfidence) return;

      // Unique ID for signal event per symbol + signal
      const signalId = `${opp.symbol}-${opp.signal}-${Math.floor(opp.price)}`;

      if (!notifiedIds.has(signalId)) {
        setNotifiedIds((prev) => new Set(prev).add(signalId));

        const newItem: SignalNotificationItem = {
          id: signalId,
          symbol: opp.symbol,
          name: opp.name,
          price: opp.price,
          change24h: opp.change24h,
          signal: opp.signal,
          confidence: opp.confidence,
          reason: opp.keyReason,
          timestamp: new Date().toLocaleTimeString(),
          read: false
        };

        // Add to history
        setNotifications((prev) => [newItem, ...prev.slice(0, 49)]);

        // Show Toast
        setActiveToast(newItem);

        // Play Audio
        if (soundEnabled) {
          if (isBuy) {
            playBuySignalSound();
          } else {
            playSellSignalSound();
          }
        }

        // Send Push Notification if granted
        if ('Notification' in window && Notification.permission === 'granted') {
          const actionText = isBuy ? '🚀 SINYAL BUY / LONG' : '🚨 SINYAL SELL / SHORT';
          new Notification(`${actionText}: ${opp.symbol}`, {
            body: `Harga: $${opp.price} (${opp.change24h > 0 ? '+' : ''}${opp.change24h.toFixed(2)}%)\nConfidence: ${opp.confidence}%\nAlasan: ${opp.keyReason}`,
            tag: opp.symbol
          });
        }
      }
    });
  }, [screenerOpportunities, notificationsEnabled, soundEnabled, minConfidence, filterType, notifiedIds]);

  // Test Notification Trigger
  const triggerTestNotification = (type: 'BUY' | 'SELL') => {
    const isBuy = type === 'BUY';
    const testItem: SignalNotificationItem = {
      id: `test-${Date.now()}`,
      symbol: isBuy ? 'BTC/USDT' : 'ETH/USDT',
      name: isBuy ? 'Bitcoin' : 'Ethereum',
      price: isBuy ? 92450.5 : 3350.2,
      change24h: isBuy ? 3.45 : -2.15,
      signal: isBuy ? 'STRONG_BUY' : 'STRONG_SELL',
      confidence: 88,
      reason: isBuy
        ? 'Breakout level resistance $92k dengan lonjakan volume +240% dan RSI bullish alignment.'
        : 'Penembusan support EMA 50 dengan indikasi overbought MACD bearish crossover.',
      timestamp: new Date().toLocaleTimeString(),
      read: false
    };

    setActiveToast(testItem);
    setNotifications((prev) => [testItem, ...prev]);

    if (soundEnabled) {
      if (isBuy) playBuySignalSound();
      else playSellSignalSound();
    }

    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(`[UJI COBA] ${isBuy ? '🚀 SINYAL BUY' : '🚨 SINYAL SELL'}: ${testItem.symbol}`, {
        body: `Confidence: ${testItem.confidence}%\n${testItem.reason}`
      });
    }
  };

  const handleOpenHistoryDrawer = () => {
    setShowHistoryDrawer(true);
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  return (
    <>
      {/* Floating Control Badge for Desktop ONLY */}
      <div className="hidden md:flex fixed bottom-6 right-6 z-40 items-center gap-2">
        <button
          onClick={handleOpenHistoryDrawer}
          className="relative px-4 py-2.5 rounded-xl bg-slate-900/95 hover:bg-slate-800 text-slate-200 border border-slate-700 shadow-2xl backdrop-blur-lg flex items-center gap-2 text-xs font-bold transition-all"
        >
          <Bell className="w-4 h-4 text-cyan-400" />
          <span>Sinyal Market</span>
          {unreadCount > 0 && (
            <span className="px-1.5 py-0.5 text-[10px] bg-rose-500 text-white font-black rounded-full animate-bounce">
              {unreadCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setShowSettingsModal(true)}
          className="p-2.5 rounded-xl bg-slate-900/95 hover:bg-slate-800 text-slate-300 border border-slate-700 shadow-2xl backdrop-blur-lg transition-all"
          title="Pengaturan Notifikasi"
        >
          <Sliders className="w-4 h-4 text-slate-300" />
        </button>
      </div>

      {/* Floating Toast Notification Banner - Responsive & Mobile-Aligned */}
      {activeToast && (
        <div className="fixed top-3 left-3 right-3 sm:left-auto sm:right-6 sm:top-20 z-50 max-w-sm sm:w-full mx-auto sm:mx-0 bg-slate-900 border-2 border-cyan-500/60 rounded-2xl p-4 shadow-2xl shadow-cyan-950/80 backdrop-blur-xl animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <span
                className={`px-2 py-0.5 rounded-md text-[11px] font-black uppercase flex items-center gap-1 ${
                  activeToast.signal.includes('BUY')
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                }`}
              >
                {activeToast.signal.includes('BUY') ? (
                  <TrendingUp className="w-3.5 h-3.5" />
                ) : (
                  <TrendingDown className="w-3.5 h-3.5" />
                )}
                {activeToast.signal.replace('_', ' ')}
              </span>
              <span className="text-xs font-mono text-cyan-400 font-bold">
                Confidence {activeToast.confidence}%
              </span>
            </div>
            <button
              onClick={() => setActiveToast(null)}
              className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="mb-2">
            <div className="flex items-baseline justify-between">
              <h4 className="text-base font-black text-slate-100">{activeToast.symbol}</h4>
              <span className="text-sm font-mono font-bold text-slate-200">
                ${activeToast.price.toLocaleString()}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 line-clamp-2 leading-relaxed">
              {activeToast.reason}
            </p>
          </div>

          <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
            <button
              onClick={() => {
                onSelectSymbolForResearch(activeToast.symbol);
                setActiveToast(null);
              }}
              className="w-full py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-cyan-500/20"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Analisis Riset AI Sekarang</span>
            </button>
          </div>
        </div>
      )}

      {/* History Drawer Modal - Slide-up Bottom Sheet on Mobile, Drawer on Desktop */}
      {showHistoryDrawer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex justify-center sm:justify-end items-end sm:items-stretch">
          <div className="bg-slate-900 border-t sm:border-l sm:border-t-0 border-slate-800 w-full sm:max-w-md max-h-[85vh] sm:max-h-full rounded-t-3xl sm:rounded-none p-5 sm:p-6 overflow-hidden flex flex-col justify-between shadow-2xl animate-in slide-in-from-bottom-5 sm:slide-in-from-right-5 duration-300">
            
            {/* Handle bar for mobile drag indicator */}
            <div className="w-12 h-1.5 bg-slate-700 rounded-full mx-auto mb-3 sm:hidden" />

            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-cyan-400" />
                  <h3 className="text-base font-black text-slate-100">
                    Riwayat Sinyal Market AI
                  </h3>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setShowHistoryDrawer(false);
                      setShowSettingsModal(true);
                    }}
                    className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 text-xs"
                    title="Pengaturan"
                  >
                    <Sliders className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowHistoryDrawer(false)}
                    className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100 text-xs"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Scrollable Signal List */}
              <div className="mt-3 space-y-2.5 overflow-y-auto max-h-[55vh] sm:max-h-[calc(100vh-180px)] pr-1 no-scrollbar">
                {notifications.length === 0 ? (
                  <div className="text-center py-12 text-slate-500 text-xs">
                    <Bell className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
                    Belum ada sinyal terdeteksi. Sistem secara otomatis memindai kriteria BUY/SELL.
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => {
                        onSelectSymbolForResearch(n.symbol);
                        setShowHistoryDrawer(false);
                      }}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 cursor-pointer transition-all space-y-1 group"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-black text-sm text-slate-200 group-hover:text-cyan-400 transition-colors">
                          {n.symbol}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                            n.signal.includes('BUY')
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {n.signal.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-snug line-clamp-2">{n.reason}</p>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 font-mono">
                        <span>${n.price.toLocaleString()}</span>
                        <span>Confidence: {n.confidence}% • {n.timestamp}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 mt-2">
              <button
                onClick={() => setNotifications([])}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all"
              >
                Bersihkan Riwayat Notifikasi
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notification Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-black text-slate-100">
                  Pengaturan Notifikasi AI
                </h3>
              </div>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Toggle 1: Enable Master Notifications */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <span className="text-xs font-bold text-slate-200 block">Notifikasi Sinyal</span>
                <span className="text-[11px] text-slate-400">Peringatan otomatis BUY/SELL</span>
              </div>
              <input
                type="checkbox"
                checked={notificationsEnabled}
                onChange={(e) => setNotificationsEnabled(e.target.checked)}
                className="w-5 h-5 accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Toggle 2: Audio Chime */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-2">
                {soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-cyan-400" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-500" />
                )}
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Suara Peringatan (Audio)</span>
                  <span className="text-[11px] text-slate-400">Bunyi chime otomatis saat sinyal muncul</span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={soundEnabled}
                onChange={(e) => setSoundEnabled(e.target.checked)}
                className="w-5 h-5 accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Toggle 3: Push Notification API */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-bold text-slate-200">Browser Push Notification</span>
                </div>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                  pushPermission === 'granted'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-amber-500/20 text-amber-400'
                }`}>
                  {pushPermission === 'granted' ? 'IZIN DIBERIKAN' : 'BELUM DIBERI IZIN'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Notifikasi tetap muncul di layar HP / Laptop Anda meskipun browser di-minimize.
              </p>
              {pushPermission !== 'granted' && (
                <button
                  onClick={requestPushPermission}
                  className="w-full py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition-colors"
                >
                  Izinkan Notifikasi Push
                </button>
              )}
            </div>

            {/* Confidence Slider */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-xs font-bold text-slate-200">
                <span>Minimal Confidence AI</span>
                <span className="font-mono text-cyan-400">{minConfidence}%</span>
              </div>
              <input
                type="range"
                min={50}
                max={90}
                step={5}
                value={minConfidence}
                onChange={(e) => setMinConfidence(Number(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block">
                Hanya beri peringatan jika skor confidence minimal {minConfidence}%
              </span>
            </div>

            {/* Filter Type Buttons */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-200 block">Filter Tipe Sinyal</span>
              <div className="grid grid-cols-3 gap-2 text-xs font-bold">
                <button
                  onClick={() => setFilterType('ALL')}
                  className={`py-1.5 rounded-lg border transition-all ${
                    filterType === 'ALL'
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  Semua
                </button>
                <button
                  onClick={() => setFilterType('BUY_ONLY')}
                  className={`py-1.5 rounded-lg border transition-all ${
                    filterType === 'BUY_ONLY'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  Hanya BUY
                </button>
                <button
                  onClick={() => setFilterType('SELL_ONLY')}
                  className={`py-1.5 rounded-lg border transition-all ${
                    filterType === 'SELL_ONLY'
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  Hanya SELL
                </button>
              </div>
            </div>

            {/* Test Notification Buttons */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <span className="text-xs font-bold text-slate-400 block">Uji Coba Suara & Notifikasi:</span>
              <div className="grid grid-cols-2 gap-2 text-xs font-bold">
                <button
                  onClick={() => triggerTestNotification('BUY')}
                  className="py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 rounded-xl flex items-center justify-center gap-1.5 transition-all"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Uji Sinyal BUY</span>
                </button>
                <button
                  onClick={() => triggerTestNotification('SELL')}
                  className="py-2 bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 rounded-xl flex items-center justify-center gap-1.5 transition-all"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Uji Sinyal SELL</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
