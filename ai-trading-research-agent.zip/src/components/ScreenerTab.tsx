import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  TrendingUp,
  TrendingDown,
  Search,
  RefreshCw,
  Zap,
  BarChart2,
  ArrowUpRight,
  Filter,
  CheckCircle2,
  AlertCircle,
  Flame,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { CryptoOpportunityItem, MarketScreenerResult } from '../types';

interface ScreenerTabProps {
  onSelectCoinForResearch: (symbol: string) => void;
  onOpportunitiesUpdate?: (opportunities: CryptoOpportunityItem[]) => void;
}

export const ScreenerTab: React.FC<ScreenerTabProps> = ({ onSelectCoinForResearch, onOpportunitiesUpdate }) => {
  const [screenerData, setScreenerData] = useState<MarketScreenerResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'BUY' | 'SELL' | 'BREAKOUT' | 'OVERSOLD'>('ALL');

  const fetchScreener = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/market/screener');
      if (res.ok) {
        const data = await res.json();
        setScreenerData(data);
        if (onOpportunitiesUpdate && Array.isArray(data.opportunities)) {
          onOpportunitiesUpdate(data.opportunities);
        }
      }
    } catch (e) {
      console.error('Failed to fetch screener data', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScreener();
  }, []);

  const opportunities = screenerData?.opportunities || [];

  const filtered = opportunities.filter(item => {
    const matchesSearch =
      item.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === 'BUY') {
      return item.signal === 'STRONG_BUY' || item.signal === 'BUY';
    }
    if (activeFilter === 'SELL') {
      return item.signal === 'STRONG_SELL' || item.signal === 'SELL';
    }
    if (activeFilter === 'BREAKOUT') {
      return item.setupType === 'Breakout Momentum' || item.setupType === 'Golden Cross Alignment';
    }
    if (activeFilter === 'OVERSOLD') {
      return item.setupType === 'Oversold Rebound' || item.rsi14 <= 40;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Hero Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-bold flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                Pemindai Pasar Crypto Berpotensi (20+ Aset)
              </span>
              {screenerData && (
                <span className="text-xs text-slate-400 font-mono">
                  {screenerData.totalScanned} Aset Terpindai | Last Update: {new Date(screenerData.timestamp).toLocaleTimeString()}
                </span>
              )}
            </div>
            <h2 className="text-2xl font-black text-slate-100">
              AI Opportunity Screener & Market Radar
            </h2>
            <p className="text-xs text-slate-400 max-w-2xl mt-1">
              Agen AI secara berkelanjutan memindai pasar crypto utama, mengevaluasi breakout teknikal, RSI oversold/overbought, pola MACD, dan lonjakan volume untuk menemukan peluang BUY/SELL berpotensi terbaik secara otomatis.
            </p>
          </div>

          <button
            onClick={fetchScreener}
            disabled={loading}
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition-all shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Pindai Ulang Seluruh Pasar</span>
          </button>
        </div>

        {/* Quick Highlights Bar */}
        {screenerData && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800 text-xs">
            
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-[11px] block">Aset Terpindai Real-Time</span>
              <span className="text-lg font-black font-mono text-slate-100">{screenerData.totalScanned} Coins</span>
            </div>

            <div className="bg-slate-950/70 p-3 rounded-xl border border-emerald-900/30">
              <span className="text-emerald-400 text-[11px] block">Peluang BUY Berpotensi</span>
              <span className="text-lg font-black font-mono text-emerald-400">{screenerData.topBuyOpportunities.length} Setups</span>
            </div>

            <div className="bg-slate-950/70 p-3 rounded-xl border border-rose-900/30">
              <span className="text-rose-400 text-[11px] block">Peluang SHORT / SELL</span>
              <span className="text-lg font-black font-mono text-rose-400">{screenerData.topSellOpportunities.length} Setups</span>
            </div>

            <div className="bg-slate-950/70 p-3 rounded-xl border border-cyan-900/30">
              <span className="text-cyan-400 text-[11px] block">Status Radar AI</span>
              <span className="text-xs font-bold text-cyan-300 font-mono block mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                Aktif & Berjalan
              </span>
            </div>

          </div>
        )}
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            onClick={() => setActiveFilter('ALL')}
            className={`px-3 py-2 rounded-xl font-bold transition-colors ${
              activeFilter === 'ALL'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            🔥 Semua Pasar ({opportunities.length})
          </button>

          <button
            onClick={() => setActiveFilter('BUY')}
            className={`px-3 py-2 rounded-xl font-bold transition-colors flex items-center gap-1.5 ${
              activeFilter === 'BUY'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>Peluang BUY ({screenerData?.topBuyOpportunities.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveFilter('SELL')}
            className={`px-3 py-2 rounded-xl font-bold transition-colors flex items-center gap-1.5 ${
              activeFilter === 'SELL'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
            <span>Peluang SHORT ({screenerData?.topSellOpportunities.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveFilter('BREAKOUT')}
            className={`px-3 py-2 rounded-xl font-bold transition-colors flex items-center gap-1.5 ${
              activeFilter === 'BREAKOUT'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-blue-400" />
            <span>Breakout & Momentum</span>
          </button>

          <button
            onClick={() => setActiveFilter('OVERSOLD')}
            className={`px-3 py-2 rounded-xl font-bold transition-colors flex items-center gap-1.5 ${
              activeFilter === 'OVERSOLD'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5 text-purple-400" />
            <span>RSI Oversold (Diskon)</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative shrink-0">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari simbol (misal: BTC, SOL, PEPE)..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl pl-9 pr-3 py-2 w-full md:w-64 focus:outline-none focus:border-cyan-500"
          />
        </div>

      </div>

      {/* Grid of Crypto Opportunities */}
      {loading && !screenerData ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-3">
          <Zap className="w-10 h-10 text-cyan-400 animate-spin mx-auto" />
          <h3 className="text-base font-bold text-slate-200">Memindai Seluruh Pasar Crypto...</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Agen AI sedang menganalisis 20+ koin crypto, memverifikasi RSI, MACD, EMA, dan volume transaksi untuk menemukan peluang perdagangan terbaik.
          </p>
        </div>
      ) : filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map(item => {
            const isBuy = item.signal === 'STRONG_BUY' || item.signal === 'BUY';
            const isSell = item.signal === 'STRONG_SELL' || item.signal === 'SELL';

            return (
              <div
                key={item.symbol}
                className={`bg-slate-900 border rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-all ${
                  isBuy
                    ? 'border-emerald-500/30 hover:shadow-emerald-500/10'
                    : isSell
                    ? 'border-rose-500/30 hover:shadow-rose-500/10'
                    : 'border-slate-800'
                }`}
              >
                {/* Header Info */}
                <div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-lg font-black text-slate-100">{item.symbol}</h3>
                        <span className="text-xs text-slate-400">({item.name})</span>
                      </div>
                      <div className="text-xl font-bold font-mono text-slate-100 mt-1">
                        ${item.price}
                      </div>
                    </div>

                    {/* Signal Badge */}
                    <div className="text-right">
                      <span className={`px-3 py-1 rounded-xl text-xs font-black font-mono block ${
                        item.signal === 'STRONG_BUY' ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20' :
                        item.signal === 'BUY' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        item.signal === 'STRONG_SELL' ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20' :
                        item.signal === 'SELL' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                        'bg-slate-800 text-slate-300'
                      }`}>
                        {item.signal}
                      </span>
                      <span className={`text-[11px] font-mono font-bold block mt-1 ${
                        item.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {item.change24h >= 0 ? '+' : ''}{item.change24h}% (24h)
                      </span>
                    </div>
                  </div>

                  {/* Setup Type & Score */}
                  <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="px-2.5 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-slate-300 font-semibold">
                      {item.setupType}
                    </span>
                    <span className="text-slate-400 font-mono text-[11px]">
                      Opportunity Score: <strong className={isBuy ? 'text-emerald-400' : isSell ? 'text-rose-400' : 'text-slate-200'}>{item.opportunityScore}</strong>
                    </span>
                  </div>

                  {/* Key Indicators Summary */}
                  <div className="grid grid-cols-3 gap-2 mt-3 text-[11px] font-mono">
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[9px]">RSI (14)</span>
                      <span className={`font-bold ${item.rsi14 <= 35 ? 'text-emerald-400' : item.rsi14 >= 68 ? 'text-rose-400' : 'text-slate-200'}`}>
                        {item.rsi14}
                      </span>
                    </div>

                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[9px]">MACD</span>
                      <span className="font-bold text-cyan-300 truncate block">
                        {item.macdTrend.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[9px]">Potensial Profit</span>
                      <span className="font-bold text-emerald-400">
                        +{item.potentialProfitPct}%
                      </span>
                    </div>
                  </div>

                  {/* Reason Text */}
                  <p className="text-[11px] text-slate-300 leading-relaxed bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 mt-3">
                    {item.keyReason}
                  </p>
                </div>

                {/* Bottom Action Button */}
                <button
                  onClick={() => onSelectCoinForResearch(item.symbol)}
                  className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md shadow-cyan-500/10 active:scale-[0.99]"
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
                  <span>Jalankan Riset AI Mendalam</span>
                  <ArrowRight className="w-3.5 h-3.5 text-cyan-200" />
                </button>

              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-3">
          <Search className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-slate-200">Tidak Ada Koin yang Cocok dengan Filter</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Coba ubah kata kunci pencarian atau ganti filter kategori di atas untuk melihat seluruh peluang pasar crypto.
          </p>
        </div>
      )}

    </div>
  );
};
