import React from 'react';
import { Waves, ArrowDownRight, ArrowUpRight, ShieldAlert, BarChart, Server } from 'lucide-react';
import { WhaleTransaction, FuturesDerivativesData } from '../types';

interface WhaleTabProps {
  currentSymbol: string;
  whales: WhaleTransaction[];
  futuresData: FuturesDerivativesData | null;
}

export const WhaleTab: React.FC<WhaleTabProps> = ({
  currentSymbol,
  whales,
  futuresData
}) => {
  return (
    <div className="space-y-6">
      
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium flex items-center justify-between">
            <span>Estimasi Likuidasi Longs</span>
            <ArrowDownRight className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black font-mono text-rose-400">
            ${((futuresData?.estimatedLiquidationLongs || 12500000) / 1e6).toFixed(2)}M
          </div>
          <p className="text-[10px] text-slate-500">Risiko likuidasi terakumulasi pada penurunan harga 2.5%</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium flex items-center justify-between">
            <span>Estimasi Likuidasi Shorts</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black font-mono text-emerald-400">
            ${((futuresData?.estimatedLiquidationShorts || 9800000) / 1e6).toFixed(2)}M
          </div>
          <p className="text-[10px] text-slate-500">Risiko short squeeze pada kenaikan harga BREAKOUT 3.0%</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium flex items-center justify-between">
            <span>Open Interest (Kontrak Aktif)</span>
            <BarChart className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black font-mono text-cyan-300">
            ${((futuresData?.openInterestUsd || 4500000000) / 1e9).toFixed(2)}B
          </div>
          <p className="text-[10px] text-slate-500">Total nilai posisi derivatif di bursa utama</p>
        </div>

      </div>

      {/* Whale Transactions Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Waves className="w-4 h-4 text-blue-400" />
            Pantauan Whale Wallet & Transaksi On-Chain Besark
          </h3>
          <span className="text-[10px] text-slate-400">Nilai Transaksi &gt; $1,000,000 USD</span>
        </div>

        <div className="space-y-3">
          {whales.map(tx => (
            <div key={tx.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    tx.type === 'EXCHANGE_OUTFLOW' ? 'bg-emerald-500/20 text-emerald-400' :
                    tx.type === 'EXCHANGE_INFLOW' ? 'bg-rose-500/20 text-rose-400' : 'bg-blue-500/20 text-blue-300'
                  }`}>
                    {tx.type}
                  </span>
                  <span className="font-mono text-slate-400 text-[11px]">{tx.hash}</span>
                </div>

                <div className="text-slate-300 font-medium">
                  {tx.from} <span className="text-slate-500">➔</span> {tx.to}
                </div>
              </div>

              <div className="text-right shrink-0">
                <div className="font-mono font-bold text-slate-100 text-sm">
                  ${(tx.amountUsd / 1e6).toFixed(2)}M USD
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {tx.amount.toLocaleString()} {tx.token}
                </div>
              </div>

            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
