import React, { useState, useEffect } from 'react';
import {
  Bot,
  Cpu,
  Activity,
  ShieldCheck,
  Hexagon,
  ChevronRight,
  TrendingUp,
  LineChart,
  Zap,
  Globe,
  Terminal,
  Lock
} from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Menginisialisasi Engine AI Trading...');
  const [activeLog, setActiveLog] = useState('[SYSTEM] Booting AI Quants Core v2.5...');
  const [isFadingOut, setIsFadingOut] = useState(false);

  // Simulated Tickers in background
  const liveTickers = [
    { symbol: 'BTC/USDT', price: '$92,485.50', change: '+4.82%', isUp: true },
    { symbol: 'ETH/USDT', price: '$3,412.10', change: '+3.15%', isUp: true },
    { symbol: 'SOL/USDT', price: '$198.40', change: '+8.90%', isUp: true },
    { symbol: 'BNB/USDT', price: '$642.80', change: '+1.45%', isUp: true },
    { symbol: 'XRP/USDT', price: '$2.35', change: '-0.85%', isUp: false }
  ];

  useEffect(() => {
    const steps = [
      { p: 15, text: 'Mengkoneksikan Engine Gemini 3.6 Flash...', log: '[GEMINI] Neural Network Initialized' },
      { p: 35, text: 'Memuat Pemindai Sinyal Pasar Real-Time...', log: '[SCANNER] Syncing 20+ Crypto Pairs' },
      { p: 60, text: 'Memverifikasi Data Multi-Exchange (Binance, OKX, Gate)...', log: '[EXCHANGE] Orderbook Depth Verified' },
      { p: 85, text: 'Menyiapkan Dashboard Riset Kuantitatif...', log: '[ANALYTICS] Technical Indicators Calibrated' },
      { p: 100, text: 'Sistem Siap Digunakan!', log: '[SUCCESS] Terminal Ready for Ahmad Sobirin' }
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setProgress(steps[currentStep].p);
        setStatusText(steps[currentStep].text);
        setActiveLog(steps[currentStep].log);
        currentStep++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsFadingOut(true);
          setTimeout(() => {
            onFinish();
          }, 400);
        }, 400);
      }
    }, 400);

    return () => clearInterval(interval);
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-50 bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-8 overflow-hidden select-none transition-opacity duration-500 ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Animated Cyber Matrix Grid & Gradient Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,_var(--tw-gradient-stops))] from-cyan-950/40 via-slate-950 to-slate-950 pointer-events-none" />
      
      {/* Subtle Grid Lines Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      {/* Ticker Stream Bar at Top */}
      <div className="relative z-10 w-full max-w-4xl mx-auto flex items-center justify-between gap-2 overflow-x-auto no-scrollbar py-1 px-3 bg-slate-900/80 border border-slate-800/80 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-widest">
            PRO TERMINAL
          </span>
        </div>

        {/* Tickers */}
        <div className="hidden sm:flex items-center gap-4 text-[11px] font-mono">
          {liveTickers.map((t, idx) => (
            <div key={idx} className="flex items-center gap-1.5 shrink-0">
              <span className="text-slate-400 font-bold">{t.symbol}</span>
              <span className="text-slate-200">{t.price}</span>
              <span className={`font-bold ${t.isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                {t.change}
              </span>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono text-slate-400">
          <Globe className="w-3 h-3 text-cyan-400" />
          <span>GLOBAL FEED</span>
        </div>
      </div>

      {/* Main Center Display - High Tech Trading Badge */}
      <div className="relative z-10 my-auto flex flex-col items-center text-center max-w-md mx-auto w-full space-y-6">
        
        {/* Futuristic Orbital Logo Icon */}
        <div className="relative flex items-center justify-center cursor-pointer" onClick={() => onFinish()}>
          {/* Outer Rotating Glowing Ring */}
          <div className="absolute w-36 h-36 rounded-full border-2 border-dashed border-cyan-500/40 animate-[spin_10s_linear_infinite]" />
          <div className="absolute w-44 h-44 rounded-full border border-blue-500/20 animate-[spin_15s_linear_infinite_reverse]" />
          
          {/* Glowing Backlight */}
          <div className="absolute w-28 h-28 bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-full blur-2xl opacity-60 animate-pulse" />

          {/* Central Glass Card */}
          <div className="relative p-7 bg-slate-900/90 border-2 border-cyan-500/50 rounded-3xl shadow-2xl shadow-cyan-950/80 backdrop-blur-2xl flex items-center justify-center group hover:scale-105 transition-transform duration-300">
            <Bot className="w-16 h-16 text-cyan-400 animate-pulse" />
            <div className="absolute -bottom-2.5 px-2.5 py-0.5 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full text-[9px] font-black text-white uppercase tracking-wider shadow-md">
              AI ENGINE 3.6
            </div>
          </div>
        </div>

        {/* Title & Creator Info */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono font-bold">
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-bounce" />
            <span>AI TRADING RESEARCH TERMINAL</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
            QUANT <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-emerald-400">RESEARCH</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-400 font-medium max-w-xs mx-auto leading-relaxed">
            Sistem Riset & Pemindai Sinyal Kuantitatif Real-Time
          </p>

          {/* Author Badge */}
          <div className="pt-2 flex justify-center">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/40 text-slate-200 text-xs font-semibold shadow-lg shadow-amber-950/30">
              <Hexagon className="w-4 h-4 text-amber-400 animate-spin" />
              <span>Dibuat oleh</span>
              <span className="text-amber-300 font-black tracking-wide">Ahmad Sobirin</span>
            </div>
          </div>
        </div>

        {/* Progress Bar & Terminal Loading Log */}
        <div className="w-full space-y-3 pt-2">
          {/* Progress Percent & Status */}
          <div className="flex justify-between items-center text-xs font-mono px-1">
            <span className="text-slate-300 font-medium truncate max-w-[260px]">{statusText}</span>
            <span className="font-bold text-cyan-400">{progress}%</span>
          </div>

          {/* Neon Gradient Progress Bar */}
          <div className="w-full h-2.5 bg-slate-900 border border-slate-800 rounded-full overflow-hidden p-0.5 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 rounded-full transition-all duration-300 shadow-md shadow-cyan-500/50"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Terminal Console Log */}
          <div className="flex items-center justify-between px-3 py-2 bg-slate-900/90 border border-slate-800/80 rounded-xl font-mono text-[10px] text-slate-400">
            <div className="flex items-center gap-2 truncate">
              <Terminal className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="text-slate-300 truncate">{activeLog}</span>
            </div>
            <span className="text-emerald-400 shrink-0 font-bold">OK</span>
          </div>
        </div>

        {/* Manual Enter Action Button */}
        <button
          onClick={() => onFinish()}
          className="mt-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-cyan-500/30 hover:border-cyan-400 text-xs font-bold rounded-xl flex items-center gap-2 transition-all shadow-lg hover:shadow-cyan-500/20 group"
        >
          <span>MASUK APLIKASI SEKARANG</span>
          <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform" />
        </button>

      </div>

      {/* Footer Features Indicator */}
      <div className="relative z-10 w-full max-w-md mx-auto pt-4 border-t border-slate-900 flex items-center justify-between text-[11px] font-mono text-slate-500">
        <div className="flex items-center gap-1.5">
          <Cpu className="w-3.5 h-3.5 text-indigo-400" />
          <span>GEMINI 3.6 FLASH</span>
        </div>
        <div className="flex items-center gap-1.5">
          <LineChart className="w-3.5 h-3.5 text-emerald-400" />
          <span>MULTI-EXCHANGE</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>PROTEKSI 0 EXEC</span>
        </div>
      </div>
    </div>
  );
};
