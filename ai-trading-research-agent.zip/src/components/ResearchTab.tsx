import React from 'react';
import {
  Sparkles,
  TrendingUp,
  TrendingDown,
  MinusCircle,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Zap,
  Check,
  ArrowUpRight,
  Target,
  BarChart3,
  Globe,
  Radio,
  FileText
} from 'lucide-react';
import { AnalysisOutput } from '../types';

interface ResearchTabProps {
  currentSymbol: string;
  analysis: AnalysisOutput | null;
  loading: boolean;
  progressStep: string;
  onTriggerResearch: () => void;
}

export const ResearchTab: React.FC<ResearchTabProps> = ({
  currentSymbol,
  analysis,
  loading,
  progressStep,
  onTriggerResearch
}) => {
  return (
    <div className="space-y-6">
      
      {/* Top Banner Action */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-md bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-semibold">
                Sistem Analisis Otonom AI
              </span>
              <span className="text-xs text-slate-400 font-mono">Pasar: {currentSymbol}</span>
            </div>
            <h2 className="text-xl font-black text-slate-100">AI Deep Research & Market Intelligence</h2>
            <p className="text-xs text-slate-400 max-w-2xl mt-1">
              Agen AI secara otomatis mengumpulkan orderbook, indikator teknikal (RSI, MACD, EMA), data whale on-chain, sentimen media sosial, serta memverifikasi silang keakuratan harga antar bursa sebelum menerbitkan rekomendasi berbukti data.
            </p>
          </div>

          <button
            onClick={onTriggerResearch}
            disabled={loading}
            className={`px-6 py-3.5 rounded-xl text-sm font-bold flex items-center gap-2.5 transition-all shadow-lg shrink-0 ${
              loading
                ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-not-allowed'
                : 'bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-cyan-500/25 hover:shadow-cyan-500/40 active:scale-[0.98]'
            }`}
          >
            {loading ? (
              <>
                <Zap className="w-4 h-4 animate-spin text-cyan-400" />
                <span>Memproses Riset AI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-cyan-200 animate-pulse" />
                <span>Jalankan Riset AI Deep Scan</span>
              </>
            )}
          </button>
        </div>

        {/* Live Loading Progress Bar */}
        {loading && (
          <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-cyan-400 font-medium flex items-center gap-2">
                <Radio className="w-3.5 h-3.5 animate-ping text-cyan-400" />
                {progressStep || 'Mengumpulkan data pasar multi-exchange...'}
              </span>
              <span className="text-slate-400 font-mono text-[10px]">Real-Time Data Pipeline</span>
            </div>
            <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden p-0.5 border border-slate-800">
              <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full animate-pulse w-3/4 transition-all duration-300"></div>
            </div>
          </div>
        )}
      </div>

      {/* Main Analysis Output View */}
      {analysis && !loading && (
        <div className="space-y-6">
          
          {/* Signal Action & Target Prices Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* Primary Action Badge */}
            <div className={`lg:col-span-5 rounded-2xl border p-6 flex flex-col justify-between shadow-xl relative overflow-hidden ${
              analysis.action === 'BUY'
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-100'
                : analysis.action === 'SELL'
                ? 'bg-rose-950/40 border-rose-500/30 text-rose-100'
                : 'bg-amber-950/40 border-amber-500/30 text-amber-100'
            }`}>
              
              <div>
                <div className="flex items-center justify-between text-xs font-semibold mb-3">
                  <span className="opacity-80 font-mono">REKOMENDASI AGEN AI</span>
                  <span className="opacity-80 font-mono text-[10px]">{new Date(analysis.timestamp).toLocaleTimeString()}</span>
                </div>

                <div className="flex items-center gap-4 my-2">
                  <div className={`p-3.5 rounded-2xl ${
                    analysis.action === 'BUY'
                      ? 'bg-emerald-500 text-slate-950'
                      : analysis.action === 'SELL'
                      ? 'bg-rose-500 text-white'
                      : 'bg-amber-500 text-slate-950'
                  }`}>
                    {analysis.action === 'BUY' && <TrendingUp className="w-9 h-9" />}
                    {analysis.action === 'SELL' && <TrendingDown className="w-9 h-9" />}
                    {analysis.action === 'HOLD' && <MinusCircle className="w-9 h-9" />}
                  </div>

                  <div>
                    <div className="text-4xl font-black tracking-tight">{analysis.action}</div>
                    <div className="text-xs font-medium opacity-90 mt-0.5">
                      {analysis.action === 'BUY' ? 'Peluang Akumulasi / Beli' : analysis.action === 'SELL' ? 'Sinyal Distribusi / Jual' : 'Kondisi Wait and See'}
                    </div>
                  </div>
                </div>

                {/* Spot vs Futures Market Target & Multi-Tier Leverage Badge */}
                <div className="mt-4 p-3.5 bg-slate-950/90 border border-slate-700/60 rounded-xl space-y-2.5 shadow-inner">
                  <div className="flex items-center justify-between text-[11px] font-bold">
                    <span className="text-cyan-400 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5" /> PASAR TARGET & LEVERAGE:
                    </span>
                    <span className="px-2 py-0.5 bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 rounded font-mono text-[10px] font-bold">
                      {analysis.action === 'BUY' ? 'SPOT & FUTURES (LONG)' : analysis.action === 'SELL' ? 'SPOT (EXIT) & FUTURES (SHORT)' : 'SPOT (HOLD) & FUTURES (WAIT)'}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-snug">
                    {analysis.targetMarketDetails}
                  </p>

                  {/* Multi-Tier Leverage Grid */}
                  <div className="pt-1.5 border-t border-slate-800/80 space-y-1.5">
                    <div className="text-[10px] text-slate-400 font-mono font-bold flex items-center justify-between">
                      <span>PILIHAN LEVERAGE FUTURES DISARANKAN:</span>
                      <span className="text-amber-300">{analysis.confidenceScore >= 82 ? '🔥 SINYAL KUAT (HINGGA 20x)' : 'MODERAT (3x - 10x)'}</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 pt-1">
                      {(analysis.leverageTiers || [
                        { tier: 'Konservatif', leverage: '3x - 5x', note: 'Risiko rendah, margin aman', estimatedLiqPrice: `~$${(analysis.currentPrice * 0.81).toFixed(2)}` },
                        { tier: 'Moderat', leverage: '5x - 10x', note: 'Keseimbangan ideal', estimatedLiqPrice: `~$${(analysis.currentPrice * 0.91).toFixed(2)}` },
                        { tier: 'Agresif (Sinyal Kuat)', leverage: '10x - 20x', note: 'Profit maksimal, wajib Stop Loss', estimatedLiqPrice: `~$${(analysis.currentPrice * 0.955).toFixed(2)}` }
                      ]).map((item, idx) => (
                        <div key={idx} className="p-2 bg-slate-900/90 border border-slate-800 rounded-lg space-y-0.5 text-left">
                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">{item.tier}</div>
                          <div className="text-xs font-black font-mono text-amber-300">{item.leverage}</div>
                          <div className="text-[9px] text-slate-400 line-clamp-2 leading-tight">{item.note}</div>
                          <div className="text-[9px] text-slate-500 font-mono pt-0.5">Est. Liq: {item.estimatedLiqPrice}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Confidence Score Bar */}
              <div className="mt-6 pt-4 border-t border-slate-700/40 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium opacity-90">Confidence Score (Skor Keyakinan):</span>
                  <span className="font-black font-mono text-sm">{analysis.confidenceScore}%</span>
                </div>
                <div className="w-full bg-slate-950/80 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      analysis.confidenceScore >= 80 ? 'bg-emerald-400' : analysis.confidenceScore >= 65 ? 'bg-amber-400' : 'bg-rose-400'
                    }`}
                    style={{ width: `${analysis.confidenceScore}%` }}
                  ></div>
                </div>
              </div>

            </div>

            {/* Target Price Parameters */}
            <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl grid grid-cols-2 sm:grid-cols-3 gap-3">
              
              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl">
                <div className="text-[11px] text-slate-400 font-medium">Harga Saat Ini</div>
                <div className="text-base font-black text-slate-100 font-mono mt-1">${analysis.currentPrice}</div>
                <div className="text-[10px] text-slate-500 mt-1">Verifikasi Multi-Source</div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl">
                <div className="text-[11px] text-blue-400 font-medium">Entry Potensial</div>
                <div className="text-base font-black text-blue-300 font-mono mt-1">${analysis.potentialEntry}</div>
                <div className="text-[10px] text-slate-500 mt-1">Optimal Risk Zone</div>
              </div>

              <div className="bg-slate-950/60 border border-rose-900/30 p-3 rounded-xl">
                <div className="text-[11px] text-rose-400 font-medium">Stop Loss (SL)</div>
                <div className="text-base font-black text-rose-300 font-mono mt-1">${analysis.suggestedStopLoss}</div>
                <div className="text-[10px] text-rose-500/80 mt-1">Manajemen Risiko</div>
              </div>

              <div className="bg-slate-950/60 border border-emerald-900/30 p-3 rounded-xl">
                <div className="text-[11px] text-emerald-400 font-medium">Take Profit 1 (TP1)</div>
                <div className="text-base font-black text-emerald-300 font-mono mt-1">${analysis.suggestedTakeProfit1}</div>
                <div className="text-[10px] text-emerald-500/80 mt-1">Target Pertama</div>
              </div>

              <div className="bg-slate-950/60 border border-emerald-900/30 p-3 rounded-xl">
                <div className="text-[11px] text-emerald-400 font-medium">Take Profit 2 (TP2)</div>
                <div className="text-base font-black text-emerald-300 font-mono mt-1">${analysis.suggestedTakeProfit2}</div>
                <div className="text-[10px] text-emerald-500/80 mt-1">Target Utama</div>
              </div>

              <div className="bg-slate-950/60 border border-emerald-900/30 p-3 rounded-xl">
                <div className="text-[11px] text-emerald-400 font-medium">Take Profit 3 (TP3)</div>
                <div className="text-base font-black text-emerald-300 font-mono mt-1">${analysis.suggestedTakeProfit3}</div>
                <div className="text-[10px] text-emerald-500/80 mt-1">Target Kenaikan Maksimal</div>
              </div>

              {/* Risk Reward Ratio Footer */}
              <div className="col-span-2 sm:col-span-3 bg-blue-500/5 border border-blue-500/20 rounded-xl p-2.5 flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">Risk / Reward Ratio (R:R):</span>
                <span className="font-bold text-blue-300 font-mono text-sm">1 : {analysis.riskRewardRatio}</span>
              </div>

            </div>

          </div>

          {/* Consolidated 5-Layer AI Matrix Synthesis Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="text-sm font-bold text-slate-100">Matriks Sintesis Multi-Layer AI</h3>
                  <p className="text-[11px] text-slate-400">Penggabungan 5 Layer Analisis Real-Time Sebelum Keputusan Final</p>
                </div>
              </div>
              <span className="px-3 py-1 bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-mono font-bold self-start sm:self-auto">
                5/5 LAYER DIGABUNGKAN
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              {/* Layer 1 */}
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>LAYER 1</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="font-bold text-slate-200">Verifikasi Harga Bursa</div>
                <div className="text-[11px] text-slate-400 font-mono">Spread: {analysis.snapshot.ticker.spreadPercent}%</div>
                <div className="text-[10px] text-emerald-400 font-medium truncate">{analysis.crossSourceVerificationProof.verificationNote}</div>
              </div>

              {/* Layer 2 */}
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>LAYER 2</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                </div>
                <div className="font-bold text-slate-200">Konfluensi Teknikal</div>
                <div className="text-[11px] text-slate-400 font-mono">RSI: {analysis.snapshot.technical.rsi14} ({analysis.snapshot.technical.rsiCondition})</div>
                <div className="text-[10px] text-cyan-300 font-medium truncate">EMA: {analysis.snapshot.technical.emaTrend}</div>
              </div>

              {/* Layer 3 */}
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>LAYER 3</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <div className="font-bold text-slate-200">Orderbook & Futures</div>
                <div className="text-[11px] text-slate-400 font-mono">Depth: {analysis.snapshot.orderbook.buySellRatio}</div>
                <div className="text-[10px] text-blue-300 font-medium truncate">Funding: {analysis.snapshot.derivatives.fundingRate}</div>
              </div>

              {/* Layer 4 */}
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>LAYER 4</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                </div>
                <div className="font-bold text-slate-200">Arus Smart Money</div>
                <div className="text-[11px] text-slate-400 font-mono">Whale Transfers</div>
                <div className="text-[10px] text-indigo-300 font-medium truncate">Outflow Accumulation</div>
              </div>

              {/* Layer 5 */}
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>LAYER 5</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                </div>
                <div className="font-bold text-slate-200">Sentimen & Makro</div>
                <div className="text-[11px] text-slate-400 font-mono">F&G: {analysis.snapshot.sentiment.fearAndGreedIndex}</div>
                <div className="text-[10px] text-purple-300 font-medium truncate">Social Score: {analysis.snapshot.sentiment.socialSentimentScore}/100</div>
              </div>
            </div>

            {/* Matrix Synthesis Result Banner */}
            <div className="bg-slate-950 border border-cyan-500/20 p-3 rounded-xl flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                Seluruh 5 layer berhasil disintesis oleh Engine AI
              </span>
              <span className="font-mono font-bold text-cyan-300">
                REKOMENDASI FINAL: <span className={analysis.action === 'BUY' ? 'text-emerald-400' : analysis.action === 'SELL' ? 'text-rose-400' : 'text-amber-400'}>{analysis.action}</span> ({analysis.confidenceScore}% Akurasi)
              </span>
            </div>
          </div>

          {/* Market Summary */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <FileText className="w-4 h-4 text-cyan-400" />
              Ringkasan Kondisi Pasar
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/50 p-3.5 rounded-xl border border-slate-800/80">
              {analysis.marketSummary}
            </p>
          </div>

          {/* Bullish & Bearish Factors Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Bullish */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                Faktor Bullish ({analysis.bullishFactors.length})
              </h3>
              <ul className="space-y-2">
                {analysis.bullishFactors.map((factor, idx) => (
                  <li key={idx} className="bg-emerald-950/20 border border-emerald-900/30 p-2.5 rounded-xl text-xs text-emerald-200 flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{factor}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Bearish */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-rose-400" />
                Faktor Bearish ({analysis.bearishFactors.length})
              </h3>
              <ul className="space-y-2">
                {analysis.bearishFactors.map((factor, idx) => (
                  <li key={idx} className="bg-rose-950/20 border border-rose-900/30 p-2.5 rounded-xl text-xs text-rose-200 flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                    <span>{factor}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

          {/* Technicals & Sentiment Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            {/* Technical Indicators */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-400" />
                Indikator Teknikal Utama
              </h3>
              <div className="space-y-2 text-xs">
                {analysis.keyTechnicalIndicatorsSummary.map((item, idx) => (
                  <div key={idx} className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                    {item}
                  </div>
                ))}
              </div>
            </div>

            {/* Market Sentiment */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Globe className="w-4 h-4 text-purple-400" />
                Sentimen Pasar & Fear/Greed
              </h3>
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-2">
                <p>{analysis.marketSentimentSummary}</p>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Fear & Greed Index:</span>
                  <span className="font-bold text-purple-300 font-mono">{analysis.snapshot.sentiment.fearAndGreedIndex}/100 ({analysis.snapshot.sentiment.fearAndGreedLabel})</span>
                </div>
              </div>
            </div>

            {/* News & Economic Events */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                Berita & Katalis Pasar
              </h3>
              <div className="space-y-2 text-xs">
                {analysis.marketImpactingNews.map((item, idx) => (
                  <div key={idx} className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-slate-300 truncate">
                    {item}
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Deep AI Evidence Reasoning */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <h3 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                Ulasan Strategis & Penjelasan Alasan Rekomendasi
              </h3>
              <span className="px-2.5 py-1 bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 rounded-full text-[11px] font-medium">
                Analisis Strategis
              </span>
            </div>
            
            <div className="bg-slate-950/90 p-5 sm:p-6 rounded-2xl border border-slate-800/80 text-sm leading-relaxed text-slate-200 font-sans space-y-3.5 shadow-inner">
              {analysis.detailedReasoning.split('\n\n').map((paragraph, idx) => (
                <p key={idx} className="text-slate-200 text-xs sm:text-sm leading-relaxed font-normal">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Verification Proof Badge */}
            <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-bold text-emerald-300">Bukti Verifikasi Multi-Exchange</div>
                  <div className="text-slate-400 text-[11px]">{analysis.crossSourceVerificationProof.verificationNote}</div>
                </div>
              </div>
              <div className="text-[11px] text-slate-400 font-mono">
                Bursa Terverifikasi: {analysis.crossSourceVerificationProof.sourcesChecked.join(', ')}
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Placeholder State */}
      {!analysis && !loading && (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center space-y-3">
          <Sparkles className="w-12 h-12 text-cyan-500/40 mx-auto animate-pulse" />
          <h3 className="text-base font-bold text-slate-200">Belum Ada Hasil Riset AI</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Klik tombol "Jalankan Riset AI Deep Scan" di atas untuk memulai pengumpulan data real-time, analisis orderbook, indikator teknikal, dan verifikasi silang bursa secara otomatis.
          </p>
        </div>
      )}

    </div>
  );
};
