export type TradeAction = 'BUY' | 'SELL' | 'HOLD';

export interface TickerData {
  symbol: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  primarySource: string;
  sourcePrices: {
    binance?: number;
    kucoin?: number;
    coingecko?: number;
    cryptocompare?: number;
  };
  spreadPercent: number;
  verificationStatus: 'VERIFIED_HIGH' | 'VERIFIED_MODERATE' | 'DISCREPANCY_WARNING' | 'SINGLE_SOURCE_FALLBACK';
  timestamp: string;
}

export interface OrderBookEntry {
  price: number;
  quantity: number;
  total: number;
}

export interface OrderBookData {
  symbol: string;
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  bidVolumeTotal: number;
  askVolumeTotal: number;
  buySellRatio: number;
  dominantSide: 'BUY_BUYERS' | 'SELL_SELLERS' | 'BALANCED';
  source: string;
}

export interface TechnicalIndicators {
  rsi14: number;
  rsiCondition: 'OVERSOLD' | 'OVERBOUGHT' | 'NEUTRAL';
  macd: {
    macdLine: number;
    signalLine: number;
    histogram: number;
    trend: 'BULLISH_CROSS' | 'BEARISH_CROSS' | 'NEUTRAL';
  };
  ema20: number;
  ema50: number;
  ema200: number;
  emaTrend: 'STRONG_BULLISH' | 'BULLISH' | 'BEARISH' | 'STRONG_BEARISH';
  bollingerBands: {
    upper: number;
    middle: number;
    lower: number;
    position: 'ABOVE_UPPER' | 'BELOW_LOWER' | 'MIDDLE_RANGE';
  };
  supportLevels: number[];
  resistanceLevels: number[];
  pivotPoints: {
    pivot: number;
    r1: number;
    r2: number;
    s1: number;
    s2: number;
  };
  detectedPatterns: string[];
}

export interface FuturesDerivativesData {
  symbol: string;
  fundingRate: number;
  fundingRateAnnualized: number;
  openInterestUsd: number;
  openInterestChange24h: number;
  estimatedLiquidationLongs: number;
  estimatedLiquidationShorts: number;
  dominantPosition: 'LONG_HEAVY' | 'SHORT_HEAVY' | 'BALANCED';
}

export interface SentimentData {
  fearAndGreedIndex: number;
  fearAndGreedLabel: string;
  socialSentimentScore: number; // -100 to +100
  socialBreakdown: {
    xTwitter: { score: number; sentiment: string; sampleCount: number };
    reddit: { score: number; sentiment: string; sampleCount: number };
    telegramDiscord: { score: number; sentiment: string; sampleCount: number };
  };
  dominantMood: 'VERY_BULLISH' | 'BULLISH' | 'NEUTRAL' | 'BEARISH' | 'VERY_BEARISH';
}

export interface NewsItem {
  id: string;
  title: string;
  source: string;
  url: string;
  publishedAt: string;
  summary: string;
  sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  impactScore: number; // 1 to 10
}

export interface EconomicEvent {
  id: string;
  eventName: string;
  country: string;
  dateTime: string;
  importance: 'HIGH' | 'MEDIUM' | 'LOW';
  actual?: string;
  forecast?: string;
  previous?: string;
  impactOnCrypto: string;
}

export interface WhaleTransaction {
  id: string;
  hash: string;
  amount: number;
  amountUsd: number;
  token: string;
  from: string;
  to: string;
  type: 'EXCHANGE_INFLOW' | 'EXCHANGE_OUTFLOW' | 'WALLET_TO_WALLET';
  timestamp: string;
}

export interface AnalysisOutput {
  id: string;
  symbol: string;
  action: TradeAction;
  confidenceScore: number; // 0 - 100%
  timestamp: string;
  
  // Key Required Outputs from User Prompt
  marketSummary: string; // Ringkasan kondisi pasar
  bullishFactors: string[]; // Faktor bullish
  bearishFactors: string[]; // Faktor bearish
  marketImpactingNews: string[]; // Berita & kalender ekonomi
  keyTechnicalIndicatorsSummary: string[]; // Indikator teknikal utama
  marketSentimentSummary: string; // Sentimen pasar
  
  // Market Instrument Recommendation (Spot vs Futures)
  targetMarket: 'SPOT' | 'FUTURES_LONG' | 'FUTURES_SHORT' | 'SPOT_AND_FUTURES_LONG' | 'SPOT_EXIT_OR_FUTURES_SHORT' | 'BOTH';
  targetMarketDetails: string;
  recommendedLeverage?: string; // e.g. "1x (Spot) / 5x - 20x (Futures)"
  leverageTiers?: Array<{
    tier: string;
    leverage: string;
    note: string;
    estimatedLiqPrice: string;
  }>;

  // Trade Parameters
  currentPrice: number;
  potentialEntry: number; // Level entry potensial
  suggestedStopLoss: number; // Stop loss
  suggestedTakeProfit1: number; // Take profit 1
  suggestedTakeProfit2: number; // Take profit 2
  suggestedTakeProfit3: number; // Take profit 3
  riskRewardRatio: number;
  
  // In-depth Reasoning & Data Evidence
  detailedReasoning: string; // Penjelasan lengkap alasan BUY/SELL/HOLD
  crossSourceVerificationProof: {
    sourcesChecked: string[];
    priceSpreadPercent: number;
    verificationNote: string;
  };
  
  // Data Snapshots captured at analysis time
  snapshot: {
    ticker: TickerData;
    technical: TechnicalIndicators;
    orderbook: OrderBookData;
    derivatives: FuturesDerivativesData;
    sentiment: SentimentData;
  };
}

export interface FailoverLog {
  id: string;
  primarySource: string;
  failedSource: string;
  usedFallbackSource: string;
  reason: string;
  timestamp: string;
}

export interface CryptoOpportunityItem {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume24h: number;
  high24h: number;
  low24h: number;
  rsi14: number;
  macdTrend: string;
  emaTrend: string;
  opportunityScore: number; // -100 to +100
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  setupType: 'Breakout Momentum' | 'Oversold Rebound' | 'Golden Cross Alignment' | 'Short Squeeze Potential' | 'Overbought Pullback' | 'Range Consolidation';
  confidence: number;
  potentialProfitPct: number;
  riskReward: string;
  keyReason: string;
}

export interface MarketScreenerResult {
  timestamp: string;
  totalScanned: number;
  opportunities: CryptoOpportunityItem[];
  topBuyOpportunities: CryptoOpportunityItem[];
  topSellOpportunities: CryptoOpportunityItem[];
}

export interface AutoScanConfig {
  enabled: boolean;
  intervalSeconds: number;
  symbols: string[];
  lastScanTimestamp?: string;
  totalScansCompleted: number;
}
