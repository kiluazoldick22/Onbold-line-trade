import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { app } from './server/app.js';
import {
  fetchMultiSourceTicker,
  calculateTechnicalIndicators,
  fetchOrderBook,
  fetchFuturesDerivatives,
  fetchMarketSentiment,
  fetchLatestNewsAndEconomicEvents,
  fetchWhaleTransactions
} from './server/marketFetcher.js';
import { runAiTradingResearch } from './server/geminiAgent.js';
import {
  saveAnalysisToDb,
  getAutoScanConfigFromDb,
  updateAutoScanConfigInDb
} from './server/database.js';

let autoScanIntervalTimer: NodeJS.Timeout | null = null;

async function executeAutoScanCycle() {
  const config = getAutoScanConfigFromDb();
  if (!config.enabled || !config.symbols || config.symbols.length === 0) return;

  console.log(`[Auto-Scan Agent] Executing automated market analysis cycle for ${config.symbols.join(', ')}...`);
  
  for (const sym of config.symbols) {
    try {
      const ticker = await fetchMultiSourceTicker(sym);
      const technical = await calculateTechnicalIndicators(sym, ticker.price);
      const orderbook = await fetchOrderBook(sym);
      const derivatives = await fetchFuturesDerivatives(sym, ticker.price);
      const sentiment = await fetchMarketSentiment();
      const { news, events } = await fetchLatestNewsAndEconomicEvents();
      const whales = fetchWhaleTransactions(sym, ticker.price);

      const research = await runAiTradingResearch(
        ticker,
        technical,
        orderbook,
        derivatives,
        sentiment,
        news,
        events,
        whales
      );

      saveAnalysisToDb(research);
      console.log(`[Auto-Scan Agent] Completed & saved analysis for ${sym} -> Action: ${research.action} (${research.confidenceScore}%)`);
    } catch (err) {
      console.error(`[Auto-Scan Agent Error on ${sym}]`, err);
    }
  }

  updateAutoScanConfigInDb({
    lastScanTimestamp: new Date().toISOString(),
    totalScansCompleted: (config.totalScansCompleted || 0) + 1
  });
}

function startOrUpdateAutoScanTimer() {
  if (autoScanIntervalTimer) {
    clearInterval(autoScanIntervalTimer);
    autoScanIntervalTimer = null;
  }

  const config = getAutoScanConfigFromDb();
  if (config.enabled) {
    const ms = Math.max(10, config.intervalSeconds || 30) * 1000;
    console.log(`[Auto-Scan Agent] Starting automated background loop every ${config.intervalSeconds}s`);
    executeAutoScanCycle();
    autoScanIntervalTimer = setInterval(executeAutoScanCycle, ms);
  }
}

async function startServer() {
  const PORT = 3000;

  // Initialize auto scan if enabled
  startOrUpdateAutoScanTimer();

  // --- VITE / STATIC SERVING ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=================================================`);
    console.log(`🤖 AI Trading Research Agent Server Running!`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log(`Port: 3000 (0.0.0.0 ingress)`);
    console.log(`=================================================`);
  });
}

startServer();
