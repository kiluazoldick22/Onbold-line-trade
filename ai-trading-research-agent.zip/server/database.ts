import fs from 'fs';
import path from 'path';
import { AnalysisOutput, FailoverLog, AutoScanConfig } from '../src/types.js';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'research_db.json');

interface Schema {
  history: AnalysisOutput[];
  failoverLogs: FailoverLog[];
  autoScanConfig: AutoScanConfig;
}

const defaultData: Schema = {
  history: [],
  failoverLogs: [],
  autoScanConfig: {
    enabled: false,
    intervalSeconds: 30,
    symbols: ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'XRP/USDT'],
    totalScansCompleted: 0
  }
};

let dbCache: Schema = { ...defaultData };

export function initDatabase() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(raw);
    } else {
      saveDatabase();
    }
    console.log(`[DB Persistence] Database initialized at ${DB_FILE}. Loaded ${dbCache.history.length} historical analyses.`);
  } catch (err) {
    console.error('[DB Persistence Error]', err);
    dbCache = { ...defaultData };
  }
}

export function saveDatabase() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(dbCache, null, 2), 'utf-8');
  } catch (err) {
    console.error('[DB Write Error]', err);
  }
}

export function saveAnalysisToDb(analysis: AnalysisOutput): AnalysisOutput {
  // Prevent duplicate if same ID
  const existingIndex = dbCache.history.findIndex(item => item.id === analysis.id);
  if (existingIndex >= 0) {
    dbCache.history[existingIndex] = analysis;
  } else {
    dbCache.history.unshift(analysis);
  }
  
  // Limit history to last 500 reports
  if (dbCache.history.length > 500) {
    dbCache.history.pop();
  }
  
  saveDatabase();
  return analysis;
}

export function getAnalysisHistoryFromDb(limit = 50, symbol?: string, action?: string): AnalysisOutput[] {
  let list = dbCache.history;
  if (symbol) {
    const cleanSym = symbol.toUpperCase().replace('-', '/');
    list = list.filter(item => item.symbol.toUpperCase().includes(cleanSym));
  }
  if (action) {
    list = list.filter(item => item.action.toUpperCase() === action.toUpperCase());
  }
  return list.slice(0, limit);
}

export function getAnalysisByIdFromDb(id: string): AnalysisOutput | undefined {
  return dbCache.history.find(item => item.id === id);
}

export function deleteAnalysisFromDb(id: string): boolean {
  const initialLen = dbCache.history.length;
  dbCache.history = dbCache.history.filter(item => item.id !== id);
  if (dbCache.history.length !== initialLen) {
    saveDatabase();
    return true;
  }
  return false;
}

export function getAutoScanConfigFromDb(): AutoScanConfig {
  return dbCache.autoScanConfig;
}

export function updateAutoScanConfigInDb(config: Partial<AutoScanConfig>): AutoScanConfig {
  dbCache.autoScanConfig = {
    ...dbCache.autoScanConfig,
    ...config
  };
  saveDatabase();
  return dbCache.autoScanConfig;
}
