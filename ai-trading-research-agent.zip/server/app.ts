import express from 'express';
import {
  fetchMultiSourceTicker,
  fetchOrderBook,
  calculateTechnicalIndicators,
  fetchFuturesDerivatives,
  fetchMarketSentiment,
  fetchLatestNewsAndEconomicEvents,
  fetchWhaleTransactions,
  scanCryptoMarketOpportunities,
  failoverLogs
} from './marketFetcher.js';
import { runAiTradingResearch } from './geminiAgent.js';
import {
  initDatabase,
  saveAnalysisToDb,
  getAnalysisHistoryFromDb,
  getAnalysisByIdFromDb,
  deleteAnalysisFromDb,
  getAutoScanConfigFromDb,
  updateAutoScanConfigInDb
} from './database.js';

// Initialize DB
initDatabase();

export const app = express();
app.use(express.json());

// --- API ROUTES ---

// 1. Ticker Endpoint
app.get('/api/market/ticker/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol || 'BTCUSDT';
    const ticker = await fetchMultiSourceTicker(symbol);
    res.json(ticker);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch ticker' });
  }
});

// 2. OrderBook Depth Endpoint
app.get('/api/market/depth/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol || 'BTCUSDT';
    const depth = await fetchOrderBook(symbol);
    res.json(depth);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch depth' });
  }
});

// 3. Technical Indicators Endpoint
app.get('/api/market/technicals/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol || 'BTCUSDT';
    const ticker = await fetchMultiSourceTicker(symbol);
    const technicals = await calculateTechnicalIndicators(symbol, ticker.price);
    res.json(technicals);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch technicals' });
  }
});

// 4. Futures Derivatives Endpoint
app.get('/api/market/futures/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol || 'BTCUSDT';
    const ticker = await fetchMultiSourceTicker(symbol);
    const futures = await fetchFuturesDerivatives(symbol, ticker.price);
    res.json(futures);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch futures data' });
  }
});

// 5. News & Economic Events Endpoint
app.get('/api/market/news', async (req, res) => {
  try {
    const data = await fetchLatestNewsAndEconomicEvents();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch news' });
  }
});

// 6. Market Sentiment Endpoint
app.get('/api/market/sentiment', async (req, res) => {
  try {
    const sentiment = await fetchMarketSentiment();
    res.json(sentiment);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch sentiment' });
  }
});

// 7. Whales Endpoint
app.get('/api/market/whales/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol || 'BTCUSDT';
    const ticker = await fetchMultiSourceTicker(symbol);
    const whales = fetchWhaleTransactions(symbol, ticker.price);
    res.json(whales);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch whale data' });
  }
});

// 7b. AI Crypto Screener & Market Opportunities Endpoint
app.get('/api/market/screener', async (req, res) => {
  try {
    const screenerResult = await scanCryptoMarketOpportunities();
    res.json(screenerResult);
  } catch (err: any) {
    console.error('[Market Screener Error]', err);
    res.status(500).json({ error: err.message || 'Failed to scan market opportunities' });
  }
});

// 8. Execute AI Research Analysis Endpoint
app.post('/api/research/analyze', async (req, res) => {
  try {
    const symbol = req.body.symbol || 'BTC/USDT';
    
    // Parallel data collection
    const [ticker, orderbook, sentiment, newsData] = await Promise.all([
      fetchMultiSourceTicker(symbol),
      fetchOrderBook(symbol),
      fetchMarketSentiment(),
      fetchLatestNewsAndEconomicEvents()
    ]);

    const [technicals, derivatives] = await Promise.all([
      calculateTechnicalIndicators(symbol, ticker.price),
      fetchFuturesDerivatives(symbol, ticker.price)
    ]);

    const whales = fetchWhaleTransactions(symbol, ticker.price);

    const research = await runAiTradingResearch(
      ticker,
      technicals,
      orderbook,
      derivatives,
      sentiment,
      newsData.news,
      newsData.events,
      whales
    );

    // Save to database automatically
    saveAnalysisToDb(research);

    res.json(research);
  } catch (err: any) {
    console.error('[Research API Error]', err);
    res.status(500).json({ error: err.message || 'Failed to run AI research' });
  }
});

// 9. Analysis History Endpoint
app.get('/api/research/history', (req, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const symbol = req.query.symbol as string;
    const action = req.query.action as string;
    const history = getAnalysisHistoryFromDb(limit, symbol, action);
    res.json(history);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to get history' });
  }
});

// 10. Get Single Research Report
app.get('/api/research/history/:id', (req, res) => {
  try {
    const item = getAnalysisByIdFromDb(req.params.id);
    if (!item) {
      return res.status(404).json({ error: 'Report not found' });
    }
    res.json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to get report' });
  }
});

// 11. Delete Single Research Report
app.delete('/api/research/history/:id', (req, res) => {
  try {
    const success = deleteAnalysisFromDb(req.params.id);
    res.json({ success });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to delete report' });
  }
});

// 12. Auto-Scan Control Endpoint
app.post('/api/agent/auto-scan', (req, res) => {
  try {
    const { enabled, intervalSeconds, symbols } = req.body;
    const updated = updateAutoScanConfigInDb({
      enabled: typeof enabled === 'boolean' ? enabled : undefined,
      intervalSeconds: typeof intervalSeconds === 'number' ? intervalSeconds : undefined,
      symbols: Array.isArray(symbols) ? symbols : undefined
    });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to update auto scan config' });
  }
});

app.get('/api/agent/auto-scan/status', (req, res) => {
  try {
    const config = getAutoScanConfigFromDb();
    res.json(config);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to get auto scan status' });
  }
});

// 13. Failover Audit Logs
app.get('/api/failover/logs', (req, res) => {
  res.json(failoverLogs);
});
