import { GoogleGenAI, Type } from '@google/genai';
import {
  AnalysisOutput,
  TickerData,
  TechnicalIndicators,
  OrderBookData,
  FuturesDerivativesData,
  SentimentData,
  NewsItem,
  EconomicEvent,
  WhaleTransaction,
  TradeAction
} from '../src/types.js';

const getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
};

/**
 * AI Research Agent synthesis that compiles and merges ALL real-time data sources
 * into a 5-layer Consolidated Synthesis Matrix:
 * Layer 1: Cross-Exchange Price Integrity & Spread Verification
 * Layer 2: Technical & Chart Pattern Confluence (RSI, MACD, EMA, Bollinger, S/R)
 * Layer 3: Market Microstructure & Orderbook Depth (Buy/Sell Ratio, Derivatives, Liquidation)
 * Layer 4: On-Chain Whale & Smart Money Flow (Exchange Outflows/Inflows)
 * Layer 5: Sentiment & Macro Economic Drivers (Fear & Greed, Social Score, News)
 *
 * Only after combining all 5 layers does it generate a high-precision, evidence-backed BUY/SELL/HOLD recommendation.
 */
export async function runAiTradingResearch(
  ticker: TickerData,
  technical: TechnicalIndicators,
  orderbook: OrderBookData,
  derivatives: FuturesDerivativesData,
  sentiment: SentimentData,
  news: NewsItem[],
  events: EconomicEvent[],
  whales: WhaleTransaction[]
): Promise<AnalysisOutput> {
  const ai = getAiClient();
  const analysisId = `res_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  // --- LAYER 1: DATA INTEGRITY SCORE (-15 to +15) ---
  let layer1Score = 0;
  if (ticker.verificationStatus === 'VERIFIED_HIGH') layer1Score = 15;
  else if (ticker.verificationStatus === 'VERIFIED_MODERATE') layer1Score = 5;
  else layer1Score = -10; // Discrepancy warning penalty

  // --- LAYER 2: TECHNICAL CONFLUENCE SCORE (-35 to +35) ---
  let layer2Score = 0;
  if (technical.rsiCondition === 'OVERSOLD') layer2Score += 12;
  else if (technical.rsiCondition === 'OVERBOUGHT') layer2Score -= 12;
  else if (technical.rsi14 <= 42) layer2Score += 5;
  else if (technical.rsi14 >= 62) layer2Score -= 5;

  if (technical.macd.trend === 'BULLISH_CROSS') layer2Score += 10;
  else if (technical.macd.trend === 'BEARISH_CROSS') layer2Score -= 10;

  if (technical.emaTrend === 'STRONG_BULLISH') layer2Score += 13;
  else if (technical.emaTrend === 'BULLISH') layer2Score += 8;
  else if (technical.emaTrend === 'STRONG_BEARISH') layer2Score -= 13;
  else if (technical.emaTrend === 'BEARISH') layer2Score -= 8;

  // --- LAYER 3: ORDERBOOK & DERIVATIVES MICROSTRUCTURE (-25 to +25) ---
  let layer3Score = 0;
  if (orderbook.dominantSide === 'BUY_BUYERS') layer3Score += 12;
  else if (orderbook.dominantSide === 'SELL_SELLERS') layer3Score -= 12;

  if (derivatives.fundingRate < 0) layer3Score += 8; // Short squeeze opportunity
  else if (derivatives.fundingRate > 0.0004) layer3Score -= 8; // Overheated long risk

  if (derivatives.estimatedLiquidationShorts > derivatives.estimatedLiquidationLongs * 1.5) {
    layer3Score += 5; // Upside squeeze potential
  } else if (derivatives.estimatedLiquidationLongs > derivatives.estimatedLiquidationShorts * 1.5) {
    layer3Score -= 5; // Downside liquidation waterfall risk
  }

  // --- LAYER 4: ON-CHAIN WHALE & SMART MONEY FLOW (-15 to +15) ---
  let layer4Score = 0;
  const buyWhales = whales.filter(w => w.type === 'EXCHANGE_OUTFLOW' || w.type === 'WALLET_TO_WALLET');
  const sellWhales = whales.filter(w => w.type === 'EXCHANGE_INFLOW');
  if (buyWhales.length > sellWhales.length) layer4Score += 12;
  else if (sellWhales.length > buyWhales.length) layer4Score -= 12;

  // --- LAYER 5: SENTIMENT & MACRO DRIVERS (-10 to +10) ---
  let layer5Score = 0;
  if (sentiment.socialSentimentScore > 20) layer5Score += 5;
  else if (sentiment.socialSentimentScore < -20) layer5Score -= 5;

  if (sentiment.fearAndGreedIndex >= 65) layer5Score += 5; // Strong market momentum
  else if (sentiment.fearAndGreedIndex <= 30) layer5Score -= 5; // High panic/caution

  // --- TOTAL AGGREGATED SINTESIS SCORE (-100 to +100) ---
  const totalScore = layer1Score + layer2Score + layer3Score + layer4Score + layer5Score;

  // Determine Action & Confidence based on consolidated 5-layer score
  let action: TradeAction = 'HOLD';
  let confidenceScore = 80;

  if (totalScore >= 20) {
    action = 'BUY';
    confidenceScore = Math.min(98, Math.max(82, 80 + Math.round(totalScore / 3)));
  } else if (totalScore <= -20) {
    action = 'SELL';
    confidenceScore = Math.min(98, Math.max(82, 80 + Math.round(Math.abs(totalScore) / 3)));
  } else {
    action = 'HOLD';
    confidenceScore = Math.min(88, Math.max(70, 75 + Math.round(10 - Math.abs(totalScore) / 2)));
  }

  // Calculate Precise Trade Parameters
  const price = ticker.price;
  let potentialEntry = price;
  let suggestedStopLoss = price;
  let suggestedTakeProfit1 = price;
  let suggestedTakeProfit2 = price;
  let suggestedTakeProfit3 = price;

  if (action === 'BUY') {
    potentialEntry = Number((price * 0.9975).toFixed(2));
    suggestedStopLoss = Number((price * 0.978).toFixed(2)); // ~2.2% SL
    suggestedTakeProfit1 = Number((price * 1.025).toFixed(2)); // +2.5%
    suggestedTakeProfit2 = Number((price * 1.050).toFixed(2)); // +5.0%
    suggestedTakeProfit3 = Number((price * 1.085).toFixed(2)); // +8.5%
  } else if (action === 'SELL') {
    potentialEntry = Number((price * 1.0025).toFixed(2));
    suggestedStopLoss = Number((price * 1.022).toFixed(2));
    suggestedTakeProfit1 = Number((price * 0.975).toFixed(2));
    suggestedTakeProfit2 = Number((price * 0.950).toFixed(2));
    suggestedTakeProfit3 = Number((price * 0.915).toFixed(2));
  } else {
    potentialEntry = price;
    suggestedStopLoss = Number((price * 0.965).toFixed(2));
    suggestedTakeProfit1 = Number((price * 1.035).toFixed(2));
    suggestedTakeProfit2 = Number((price * 1.060).toFixed(2));
    suggestedTakeProfit3 = Number((price * 1.090).toFixed(2));
  }

  const riskAmt = Math.abs(potentialEntry - suggestedStopLoss);
  const rewardAmt = Math.abs(suggestedTakeProfit2 - potentialEntry);
  const riskRewardRatio = riskAmt > 0 ? Number((rewardAmt / riskAmt).toFixed(2)) : 2.2;

  // Determine Market Instrument Details & Dynamic Multi-Tier Leverage based on Signal Strength
  let targetMarket: 'SPOT' | 'FUTURES_LONG' | 'FUTURES_SHORT' | 'SPOT_AND_FUTURES_LONG' | 'SPOT_EXIT_OR_FUTURES_SHORT' | 'BOTH' = 'BOTH';
  let targetMarketDetails = 'Berlaku untuk Pasar Spot dan Futures';
  let recommendedLeverage = 'SPOT: 1x | FUTURES: 5x - 20x (Disesuaikan Profil Risiko)';
  let leverageTiers: Array<{ tier: string; leverage: string; note: string; estimatedLiqPrice: string }> = [];

  const isStrongSignal = confidenceScore >= 82 || Math.abs(totalScore) >= 20;

  if (action === 'BUY') {
    targetMarket = 'SPOT_AND_FUTURES_LONG';
    targetMarketDetails = 'Rekomendasi Beli: Berlaku di Pasar SPOT (Aman tanpa likuidasi) & Posisi LONG di Futures/Perpetual untuk profit berlipat.';
    recommendedLeverage = isStrongSignal
      ? 'SPOT: 1x (Beli Fisik) | FUTURES: 5x s/d 20x LONG (Sinyal Kuat)'
      : 'SPOT: 1x (Beli Fisik) | FUTURES: 3x s/d 10x LONG';

    leverageTiers = [
      {
        tier: 'Konservatif (Aman & Swing Trade)',
        leverage: '3x - 5x LONG',
        note: 'Buffer likuidasi sangat aman (~18-25%), cocok untuk hold jangka menengah.',
        estimatedLiqPrice: `$${(price * 0.81).toFixed(2)}`
      },
      {
        tier: 'Moderat (Standar Day Trade)',
        leverage: '5x - 10x LONG',
        note: 'Keseimbangan ideal antara potensi profit dan pengelolaan risiko.',
        estimatedLiqPrice: `$${(price * 0.91).toFixed(2)}`
      },
      {
        tier: isStrongSignal ? 'Agresif (Sinyal Kuat / Momentum)' : 'Agresif (High Risk)',
        leverage: isStrongSignal ? '10x - 20x LONG' : '10x - 12x LONG',
        note: `Memaksimalkan profit dari sinyal kuat. WAJIB pasang Stop Loss ketat di $${suggestedStopLoss}.`,
        estimatedLiqPrice: `$${(price * 0.955).toFixed(2)}`
      }
    ];
  } else if (action === 'SELL') {
    targetMarket = 'SPOT_EXIT_OR_FUTURES_SHORT';
    targetMarketDetails = 'Rekomendasi Jual: Di SPOT segera Take Profit/Cashout ke USDT. Di FUTURES buka posisi SHORT untuk profit saat harga turun.';
    recommendedLeverage = isStrongSignal
      ? 'SPOT: Cash Out USDT | FUTURES: 5x s/d 20x SHORT (Sinyal Kuat)'
      : 'SPOT: Cash Out USDT | FUTURES: 3x s/d 10x SHORT';

    leverageTiers = [
      {
        tier: 'Konservatif (Aman & Swing Trade)',
        leverage: '3x - 5x SHORT',
        note: 'Batas likuidasi atas cukup tinggi (+20%), aman dari spike volatilitas sementara.',
        estimatedLiqPrice: `$${(price * 1.19).toFixed(2)}`
      },
      {
        tier: 'Moderat (Standar Day Trade)',
        leverage: '5x - 10x SHORT',
        note: 'Pengambilan keuntungan optimal dengan risiko terukur.',
        estimatedLiqPrice: `$${(price * 1.09).toFixed(2)}`
      },
      {
        tier: isStrongSignal ? 'Agresif (Sinyal Kuat / Short Squeeze Target)' : 'Agresif (High Risk)',
        leverage: isStrongSignal ? '10x - 20x SHORT' : '10x - 12x SHORT',
        note: `Target profit kilat dari tekanan jual. WAJIB pasang Stop Loss di $${suggestedStopLoss}.`,
        estimatedLiqPrice: `$${(price * 1.045).toFixed(2)}`
      }
    ];
  } else {
    targetMarket = 'BOTH';
    targetMarketDetails = 'Pasar dalam fase konsolidasi/sideways. Di SPOT: Tahan (HOLD). Di FUTURES: Wait & See (Jangan entry dulu).';
    recommendedLeverage = '0x - 1x (Tahan Diri / Wait & See)';
    leverageTiers = [
      {
        tier: 'Konservatif',
        leverage: '1x SPOT (Hold)',
        note: 'Simpan posisi aset tanpa leverage sampai sinyal breakout terkonfirmasi.',
        estimatedLiqPrice: 'Tanpa Likuidasi (0)'
      },
      {
        tier: 'Moderat & Agresif',
        leverage: '0x FUTURES (Wait)',
        note: 'Hindari membuka posisi leverage baru di pasar ber-volatilitas acak.',
        estimatedLiqPrice: 'N/A'
      }
    ];
  }

  // Structured Prompt construction for Gemini to generate strict 5-layer synthesis
  const promptText = `
Anda adalah **Senior Quant & Crypto Research Strategist**. Tugas Anda adalah memberikan ulasan analisis riset pasar secara mendalam, elegan, profesional, dan mudah dipahami (NATIVE HUMAN ANALYST STYLE, BUKAN ROBOTIK ATO KAKU).

Gunakan bahasa Indonesia yang mengalir, komunikatif, berbasis data, dan meyakinkan tanpa menggunakan penomoran kaku seperti [Layer 1] atau format robotik.

DATA PASAR REAL-TIME SAAT INI:
- Simbol: ${ticker.symbol} | Harga Utama (${ticker.primarySource}): $${ticker.price} (24h: ${ticker.change24h}%)
- Beda Harga Exchange (Spread): ${ticker.spreadPercent}% (Verifikasi: ${ticker.verificationStatus})
- Teknikal: RSI ${technical.rsi14} (${technical.rsiCondition}), MACD ${technical.macd.trend}, EMA ${technical.emaTrend}, Support $${technical.supportLevels[0]}, Resistance $${technical.resistanceLevels[0]}
- Microstructure Orderbook: Buy/Sell Ratio ${orderbook.buySellRatio} (${orderbook.dominantSide}), Funding Rate ${derivatives.fundingRate}
- Sentimen & Macro: Fear & Greed ${sentiment.fearAndGreedIndex} (${sentiment.fearAndGreedLabel}), Social Score ${sentiment.socialSentimentScore}/100
- Rekomendasi Terhitung: ${action} (Akurasi: ${confidenceScore}%)
- Pasar Target: ${targetMarketDetails}

BERIKAN OUTPUT DALAM FORMAT JSON BERIKUT:
{
  "action": "${action}",
  "confidenceScore": ${confidenceScore},
  "marketSummary": "Ringkasan kondisi pasar secara tajam dan natural dalam 3-4 kalimat.",
  "bullishFactors": ["Pendorong positif 1", "Pendorong positif 2", "Pendorong positif 3"],
  "bearishFactors": ["Tantangan/Risiko 1", "Tantangan/Risiko 2", "Tantangan/Risiko 3"],
  "marketImpactingNews": ["Kabar pasar utama beserta dampaknya"],
  "keyTechnicalIndicatorsSummary": [
    "Sintesis Teknikal RSI (${technical.rsi14}) & EMA (${technical.emaTrend})",
    "Struktur Kedalaman Orderbook & Likuidasi Futures"
  ],
  "marketSentimentSummary": "Sintesis arus dana Whale, Fear & Greed (${sentiment.fearAndGreedIndex}), serta psikologi pasar.",
  "detailedReasoning": "Tuliskan penjelasan komprehensif, mengalir secara natural seperti ulasan analis profesional terkemuka (tanpa format robotik/kaku). Jelaskan bagaimana integrasi harga bursa, indikator teknikal, kedalaman orderbook, pergerakan paus, dan sentimen publik saling mengonfirmasi rekomendasi ${action} ini."
}
`;

  if (ai) {
    const candidateModels = ['gemini-2.5-flash', 'gemini-2.0-flash'];
    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: promptText,
          config: {
            temperature: 0.15, // Low temperature for high objectivity and precision
            responseMimeType: 'application/json'
          }
        });

        const responseText = response.text;
        if (responseText) {
          const parsed = JSON.parse(responseText.trim());
          return {
            id: analysisId,
            symbol: ticker.symbol,
            action: (parsed.action || action) as TradeAction,
            confidenceScore: typeof parsed.confidenceScore === 'number' ? Math.min(99, Math.max(50, parsed.confidenceScore)) : confidenceScore,
            timestamp: new Date().toISOString(),
            targetMarket,
            targetMarketDetails,
            recommendedLeverage,
            leverageTiers,
            marketSummary: parsed.marketSummary || `Sintesis multi-layer untuk ${ticker.symbol} menunjukkan konsensus ${action} pada harga $${ticker.price} dengan skor konfluensi ${totalScore}.`,
            bullishFactors: Array.isArray(parsed.bullishFactors) ? parsed.bullishFactors : [`RSI di level ${technical.rsi14} (${technical.rsiCondition})`, `Orderbook didominasi ${orderbook.dominantSide}`, `Verifikasi harga bursa konsisten (Spread ${ticker.spreadPercent}%)`],
            bearishFactors: Array.isArray(parsed.bearishFactors) ? parsed.bearishFactors : [`Resistance terdekat di $${technical.resistanceLevels[0]}`, `Funding rate futures di level ${derivatives.fundingRate}`],
            marketImpactingNews: Array.isArray(parsed.marketImpactingNews) ? parsed.marketImpactingNews : news.map(n => `[${n.source}] ${n.title}`),
            keyTechnicalIndicatorsSummary: Array.isArray(parsed.keyTechnicalIndicatorsSummary) ? parsed.keyTechnicalIndicatorsSummary : [`Layer 1&2: RSI ${technical.rsi14}, EMA ${technical.emaTrend}`, `Layer 3: Orderbook Ratio ${orderbook.buySellRatio}`],
            marketSentimentSummary: parsed.marketSentimentSummary || `Fear & Greed Index menunjukkan ${sentiment.fearAndGreedIndex} (${sentiment.fearAndGreedLabel}) dengan arus whale ${layer4Score > 0 ? 'bullish' : 'netral'}.`,
            currentPrice: ticker.price,
            potentialEntry,
            suggestedStopLoss,
            suggestedTakeProfit1,
            suggestedTakeProfit2,
            suggestedTakeProfit3,
            riskRewardRatio,
            detailedReasoning: parsed.detailedReasoning || `Berdasarkan evaluasi menyeluruh dari data pasar real-time, kami menyimpulkan keputusan ${action} untuk ${ticker.symbol} di kisaran harga $${ticker.price}.\n\nIntegrasi data diawali dengan verifikasi harga antar-bursa utama (Binance, OKX, dan KuCoin) yang menunjukkan selisih harga sangat tipis sebesar ${ticker.spreadPercent}%, menandakan integritas data yang sangat stabil.\n\nSecara teknikal, indikator RSI berada di level ${technical.rsi14} (${technical.rsiCondition}) dengan tren EMA ${technical.emaTrend}. Struktur ini diperkuat oleh kondisi mikrostruktur orderbook yang mencatatkan dominansi ${orderbook.dominantSide === 'BUY_BUYERS' ? 'pembeli' : 'penjual'} dengan rasio ${orderbook.buySellRatio}, serta posisi akumulasi paus on-chain dan indeks Fear & Greed pada level ${sentiment.fearAndGreedIndex}.\n\nKombinasi seluruh indikator tersebut memberikan konfluensi sinyal yang konsisten untuk mengeksekusi rekomendasi ${action} ini secara terukur.`,
            crossSourceVerificationProof: {
              sourcesChecked: Object.keys(ticker.sourcePrices).map(s => s.toUpperCase()),
              priceSpreadPercent: ticker.spreadPercent,
              verificationNote: ticker.verificationStatus === 'VERIFIED_HIGH'
                ? `Keakuratan data TERVERIFIKASI SANGAT TINGGI dengan selisih harga antar exchange hanya ${ticker.spreadPercent}%.`
                : ticker.verificationStatus === 'VERIFIED_MODERATE'
                ? `Keakuratan data Terverifikasi Sedang dengan spread ${ticker.spreadPercent}%.`
                : `Terdeteksi sedikit variasi harga antar-exchange (${ticker.spreadPercent}%). Gunakan batas toleransi harga saat entry.`
            },
            snapshot: {
              ticker,
              technical,
              orderbook,
              derivatives,
              sentiment
            }
          };
        }
      } catch (err: any) {
        break;
      }
    }
  }

  // Pure Deterministic Synthesis Engine Fallback
  return {
    id: analysisId,
    symbol: ticker.symbol,
    action,
    confidenceScore,
    timestamp: new Date().toISOString(),
    targetMarket,
    targetMarketDetails,
    recommendedLeverage,
    marketSummary: `Sintesis multi-layer untuk ${ticker.symbol} menggabungkan 5 sumber analisis utama: Verifikasi bursa (Spread ${ticker.spreadPercent}%), Indikator teknikal (${technical.rsiCondition}, ${technical.emaTrend}), Orderbook depth (${orderbook.dominantSide}), Arus Whale on-chain, dan Sentimen pasar (${sentiment.fearAndGreedLabel}).`,
    bullishFactors: [
      `Layer 2 Teknikal: RSI ${technical.rsi14} (${technical.rsiCondition}) dengan tren MACD ${technical.macd.trend}`,
      `Layer 3 Orderbook: Dominansi pembeli mencatatkan rasio ${orderbook.buySellRatio}`,
      `Layer 1 Verifikasi: Selisih harga antar-bursa (Binance, OKX, Gate) sangat presisi (${ticker.spreadPercent}%)`
    ],
    bearishFactors: [
      `Level resistensi terdekat membatasi kenaikan di $${technical.resistanceLevels[0]}`,
      `Funding rate kontrak futures berada pada angka ${derivatives.fundingRate} (${derivatives.dominantPosition})`,
      `Ketidakpastian inflasi makroekonomi jelang rilis data CPI/FOMC`
    ],
    marketImpactingNews: news.map(n => `[${n.source}] ${n.title} (Sentimen: ${n.sentiment})`),
    keyTechnicalIndicatorsSummary: [
      `Layer 1&2: RSI (14) = ${technical.rsi14} (${technical.rsiCondition}) | EMA Trend = ${technical.emaTrend}`,
      `Layer 3: Orderbook Ratio = ${orderbook.buySellRatio} (${orderbook.dominantSide})`,
      `Pivot Point $${technical.pivotPoints.pivot} | Support: $${technical.supportLevels[0]} | Resistance: $${technical.resistanceLevels[0]}`
    ],
    marketSentimentSummary: `Sentimen pasar saat ini dinilai ${sentiment.dominantMood} dengan Fear & Greed Index pada angka ${sentiment.fearAndGreedIndex} (${sentiment.fearAndGreedLabel}).`,
    currentPrice: ticker.price,
    potentialEntry,
    suggestedStopLoss,
    suggestedTakeProfit1,
    suggestedTakeProfit2,
    suggestedTakeProfit3,
    riskRewardRatio,
    detailedReasoning: `Berdasarkan evaluasi menyeluruh dari data pasar real-time, kami menyimpulkan keputusan ${action} untuk ${ticker.symbol} di kisaran harga $${ticker.price}.\n\nIntegrasi data diawali dengan verifikasi harga antar-bursa utama (Binance, OKX, dan KuCoin) yang menunjukkan selisih harga sangat tipis sebesar ${ticker.spreadPercent}%, menandakan integritas data yang sangat stabil.\n\nSecara teknikal, indikator RSI berada di level ${technical.rsi14} (${technical.rsiCondition}) dengan tren EMA ${technical.emaTrend}. Struktur ini diperkuat oleh kondisi mikrostruktur orderbook yang mencatatkan dominansi ${orderbook.dominantSide === 'BUY_BUYERS' ? 'pembeli' : 'penjual'} dengan rasio ${orderbook.buySellRatio}, serta posisi akumulasi paus on-chain dan indeks Fear & Greed pada level ${sentiment.fearAndGreedIndex}.\n\nKombinasi seluruh indikator tersebut memberikan konfluensi sinyal yang konsisten untuk mengeksekusi rekomendasi ${action} ini secara terukur dengan tingkat keyakinan ${confidenceScore}%.`,
    crossSourceVerificationProof: {
      sourcesChecked: Object.keys(ticker.sourcePrices).map(s => s.toUpperCase()),
      priceSpreadPercent: ticker.spreadPercent,
      verificationNote: ticker.verificationStatus === 'VERIFIED_HIGH'
        ? `Keakuratan data TERVERIFIKASI SANGAT TINGGI dengan selisih harga antar exchange hanya ${ticker.spreadPercent}%.`
        : `Keakuratan data telah diverifikasi silang antar sumber bursa.`
    },
    snapshot: {
      ticker,
      technical,
      orderbook,
      derivatives,
      sentiment
    }
  };
}

